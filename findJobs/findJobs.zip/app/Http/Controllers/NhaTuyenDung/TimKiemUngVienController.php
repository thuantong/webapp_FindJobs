<?php

namespace App\Http\Controllers\NhaTuyenDung;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TimKiemUngVienController extends Controller
{
    //
}
