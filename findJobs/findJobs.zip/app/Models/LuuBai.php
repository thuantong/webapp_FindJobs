<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LuuBai extends Model
{
    protected $table = 'luu_bai';
    protected $primaryKey  = 'id';
    public $timestamps = true;
//    protected $fillable = ['name', 'prefix'];
    //

}
