<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BaiTuyenDungNganhNghe extends Model
{
    //
    protected $table = 'bai_tuyen_dung_nganh_nghe';
    protected $primaryKey = 'id';
}
