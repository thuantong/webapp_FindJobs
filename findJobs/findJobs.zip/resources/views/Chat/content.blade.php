<div class="row their-message">
    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10 p-1">
        <div class="pl-1 pr-1 border" style="border-radius: 10px;">ádasdsadasd asdasdasdasd asda sdas dsad asd asd asdas dá dasdasd ádasdasdasdas</div>
    </div>
    <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 p-0 my-message center-element">
        <div class="font-10 nowrap">Đã xem</div>
    </div>
</div>

<div class="row their-message">
    <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 p-0 my-message center-element">
        <div class="font-10 nowrap">Đã Gửi</div>
    </div>
    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10 p-1 ">
        <div class="pl-1 pr-1" style="border-radius: 10px;background-color: rgba(139,216,255,0.4)">ádasdsadasd asdasdasdasd asda sdas dsad asd asd asdas dá dasdasd ádasdasdasdas</div>
    </div>

</div>
<div class="row their-message">
    <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 p-0 my-message center-element">
        <div class="font-10 nowrap">Đã Gửi</div>
    </div>
    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10 p-1 ">
        <div class="pl-1 pr-1" style="border-radius: 10px;background-color: rgba(139,216,255,0.4)">ádasdsadasd asdasdasdasd asda sdas dsad asd asd asdas dá dasdasd ádasdasdasdas</div>
    </div>

</div>
<div class="row their-message">
    <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 p-0 my-message center-element">
        <div class="font-10 nowrap">Đã Gửi</div>
    </div>
    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10 p-1 ">
        <div class="pl-1 pr-1" style="border-radius: 10px;background-color: rgba(139,216,255,0.4)">ádasdsadasd asdasdasdasd asda sdas dsad asd asd asdas dá dasdasd ádasdasdasdas</div>
    </div>

</div>
<div class="row their-message">
    <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 p-0 my-message center-element">
        <div class="font-10 nowrap">Đã Gửi</div>
    </div>
    <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10 p-1 ">
        <div class="pl-1 pr-1" style="border-radius: 10px;background-color: rgba(139,216,255,0.4)">ádasdsadasd asdasdasdasd asda sdas dsad asd asd asdas dá dasdasd ádasdasdasdas</div>
    </div>

</div>
