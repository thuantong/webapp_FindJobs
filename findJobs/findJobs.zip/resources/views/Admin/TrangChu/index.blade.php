@extends('master.index')
@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item active">Trang quản trị</li>
                    </ol>
                </div>
                <h4 class="page-title">Trang quản trị</h4>
            </div>
        </div>
    </div>

    <div class="card-box">
        <div class="row">
            <div class="col-md-6 col-xl-3">
                <div class="card-box">
{{--                    <i class="fa fa-info-circle text-muted float-right" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="More Info"></i>--}}
                    <h4 class="mt-0 font-16">Số lượng người dùng</h4>
                    <h2 class="text-primary my-3 text-center"><span data-plugin="counterup">{{\App\Models\TaiKhoan::all()->count()}}</span></h2>
{{--                    <p class="text-muted mb-0">Total income: $22506 <span class="float-right"><i class="fa fa-caret-up text-success mr-1"></i>10.25%</span></p>--}}
                </div>
            </div>

            <div class="col-md-6 col-xl-3">
                <div class="card-box">
{{--                    <i class="fa fa-info-circle text-muted float-right" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="More Info"></i>--}}
                    <h4 class="mt-0 font-16">Bài tuyển dụng chờ duyệt</h4>
                    <h2 class="text-primary my-3 text-center"><span data-plugin="counterup">{{\App\Models\BaiTuyenDung::query()->where('status',0)->count()}}</span></h2>
{{--                    <p class="text-muted mb-0">Total sales: 2398 <span class="float-right"><i class="fa fa-caret-down text-danger mr-1"></i>7.85%</span></p>--}}
                </div>
            </div>

            <div class="col-md-6 col-xl-3">
                <div class="card-box">
{{--                    <i class="fa fa-info-circle text-muted float-right" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="More Info"></i>--}}
                    <h4 class="mt-0 font-16">Bài tuyển dụng đang tuyển</h4>
                    <h2 class="text-primary my-3 text-center"><span data-plugin="counterup">{{\App\Models\BaiTuyenDung::query()->where('status',1)->count()}}</span></h2>
{{--                    <p class="text-muted mb-0">Total users: 121 M <span class="float-right"><i class="fa fa-caret-up text-success mr-1"></i>3.64%</span></p>--}}
                </div>
            </div>

            <div class="col-md-6 col-xl-3">
                <div class="card-box">
{{--                    <i class="fa fa-info-circle text-muted float-right" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="More Info"></i>--}}
                    <h4 class="mt-0 font-16">Tổng doanh thu</h4>
                    <h2 class="text-primary my-3 text-center"><span data-plugin="counterup">{{\App\Models\DonHang::query()->sum('so_luong')}}</span> Xu</h2>
{{--                    <p class="text-muted mb-0">Total revenue: $1.2 M <span class="float-right"><i class="fa fa-caret-up text-success mr-1"></i>17.48%</span></p>--}}
                </div>
            </div>
        </div>
    </div>
    @endsection
