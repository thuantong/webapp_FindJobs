@extends('Admin.index')
@section('content')
    trang chu
    @endsection
