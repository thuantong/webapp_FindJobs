<select class="form-control select2 project-status-select" style="text-overflow: ellipsis" title="Trạng thái của dự án">
    <option disabled selected value="">{{__('-- Chưa chọn --')}}</option>
    <option value="1"><span class="badge badge-info">Đang tiến hành</span></option>
    <option value="2"><span class="badge badge-pink">Đang chờ xử lý</span></option>
    <option value="3"><span class="badge badge-success">Hoàn thành</span></option>
    <option value="4"><span class="badge badge-warning">Sắp có</span></option>
</select>
