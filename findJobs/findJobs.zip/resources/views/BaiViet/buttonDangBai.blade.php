{{--<div class="col-sm-12 col-md-12">--}}
    <button class="btn btn-success save-bai-tuyen-dung" id="save">Đăng bài</button>
    <button class="btn btn-info d-none review" id="review">Xem trước</button>

{{--</div>--}}
