<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NganhNgheCongTy extends Model
{
    protected $table = 'nganh_nghe_cong_ty';
    protected $primaryKey  = 'id';
    //
}
