<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuanTam extends Model
{
    protected $table = 'quan_tam';
    protected $primaryKey  = 'id';
//    protected $fillable = ['nha_tuyen_dung_id'];
//    protected $attributes = [
//        'status' => 1,
//    ];
    //

}

