<?php
namespace App\Traits;

trait StoredUserTrait
{
    public function getEmployee($id){
        return view('User.nguoiTimViec');
    }
}
