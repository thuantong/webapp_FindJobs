<?php
namespace App\Traits;

trait GetResponseTrait{
//    protected function getResponse($title,$status,$message,...$reset){
//        if($status == 200){
//            $status_text = 'Thành công';
//        }elseif($status == 400){
//            $status_text = 'Thất bại';
//        }
//        return array(
//            'title'=> $title,
//            'status_text'=>$status_text,
//            'status'=>$status,
//            'message'=>$message,
//            'reset'=>$reset
//        );
//    }
}
