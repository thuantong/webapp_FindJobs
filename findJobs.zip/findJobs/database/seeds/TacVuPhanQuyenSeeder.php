<?php

use Illuminate\Database\Seeder;

class TacVuPhanQuyenSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        DB::table('tac_vu_phan_quyen')->insert([
//            array(
//                'tac_vu_id'=> 1,//xem
//                'phan_quyen_id'=> 1
//            ),array(
//                'tac_vu_id'=> 3,//sửa thông tin cá nhân
//                'phan_quyen_id'=> 1
//            ),
//
//            array(
//                'tac_vu_id'=> 1,
//                'phan_quyen_id'=> 2
//            ),array(
//                'tac_vu_id'=> 2,
//                'phan_quyen_id'=> 2
//            ),array(
//                'tac_vu_id'=> 3,
//                'phan_quyen_id'=> 2
//            ),array(
//                'tac_vu_id'=> 5,
//                'phan_quyen_id'=> 2
//            ),
//
//            array(
//                'tac_vu_id'=> 1,
//                'phan_quyen_id'=> 3
//            ),
//            array(
//                'tac_vu_id'=> 2,
//                'phan_quyen_id'=> 3
//            ),array(
//                'tac_vu_id'=> 3,
//                'phan_quyen_id'=> 3
//            ),array(
//                'tac_vu_id'=> 4,
//                'phan_quyen_id'=> 3
//            ),array(
//                'tac_vu_id'=> 5,
//                'phan_quyen_id'=> 3
//            ),array(
//                'tac_vu_id'=> 6,
//                'phan_quyen_id'=> 3
//            ),
//
//        ]);

        //
    }
}
