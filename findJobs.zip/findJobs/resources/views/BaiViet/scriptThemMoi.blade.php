<script type="text/javascript" src="{{URL::asset('assets\js\app\nhaTuyenDung_dang_bai.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('assets\js\app\themMoiCongTy.js')}}"></script>
