@extends('master.index')
@section('content')
    @endsection
@push('scripts')
    <script>

    </script>
    @endpush
