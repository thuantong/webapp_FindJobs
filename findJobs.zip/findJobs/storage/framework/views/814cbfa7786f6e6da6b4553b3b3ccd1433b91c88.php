
<?php if($nguoiTimViec): ?>
    
    <?php if($nguoiTimViec['ky_nang'] != ''): ?>
        <?php $__currentLoopData = unserialize($nguoiTimViec['ky_nang']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="pt-1 skill">
                <h6 class="text-uppercase mt-0 mb-1 row">
                    <label class="col-6 mb-0"><input class="skill-name" data-value="<?php echo e($row['value']); ?>" data-prefix = "<?php echo e($row['prefix']); ?>" title="<?php echo e($row['name']); ?>" value="<?php echo e($row['name']); ?>"></label>

                    <span class="float-right col-4 text-right"><span
                            class="skill_value"></span> Điểm</span>
                    <div class="col-2 text-right">
                        <button class="btn btn-sm btn-danger pt-0 pb-0 pr-1 pl-1 remove-skill"><?php echo e(__('-')); ?></button>
                    </div>

                </h6>
                <input type="text" class="skill_append" data-value="<?php echo e($row['value']); ?>" id="skill_append">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<?php endif; ?>






<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/User/nguoiTimViec/skill.blade.php ENDPATH**/ ?>