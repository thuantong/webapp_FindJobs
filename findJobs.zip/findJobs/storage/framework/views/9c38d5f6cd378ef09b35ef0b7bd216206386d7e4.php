<div class="modal fade" id="modal-them-moi-tai-khoan" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalScrollableTitle"><?php echo e(__('Tạo mới tài khoản')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">



                    <div class="form-group row">
                        
                        <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Họ và tên')); ?></label>

                        <div class="col-md-6">
                            <input id="name" type="text" class="form-control not-null" name="name" value="" required autocomplete="off" autofocus>

                            <span class="invalid-feedback" role="alert">
                                        <strong></strong>
                                    </span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tên tài khoản hoặc Email:')); ?></label>

                        <div class="col-md-6">
                            <input id="email" type="text" class="form-control not-null" name="email" value="" required autocomplete="off">

                            <span class="invalid-feedback" role="alert">
                                        <strong></strong>
                                    </span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Số điện thoại')); ?></label>

                        <div class="col-md-6">
                            <input id="phone" type="text" class="form-control not-null" name="phone" value="" required autocomplete="off">

                            <span class="invalid-feedback" role="alert">
                                        <strong></strong>
                                    </span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Mật khẩu')); ?></label>

                        <div class="col-md-6">
                            <input id="password" type="password" class="form-control not-null" name="password" required autocomplete="new-password">


                            <span class="invalid-feedback" role="alert">
                                        <strong></strong>
                                    </span>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nhập lại mật khẩu')); ?></label>

                        <div class="col-md-6">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                        </div>
                    </div>

                                            <div class="form-group row">
                                                <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__(' ')); ?></label>

                                                <div class="col-md-6">
                                                    <?php if($data['phan_quyen'] != null): ?>

                                                    <?php $__currentLoopData = $data['phan_quyen']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" id="customRadio<?php echo e($row['id']); ?>" name="loai_tai_khoan" class="custom-control-input" value="<?php echo e($row['id']); ?>">
                                                        <label class="custom-control-label" for="customRadio<?php echo e($row['id']); ?>"><?php echo e($row['name']); ?></label>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>








                                                </div>
                                            </div>




            </div>
            <div class="modal-footer">

                <button type="button" class="btn btn-secondary float-left" data-dismiss="modal"><?php echo e(__('Thoát')); ?></button>
                <button type="button" class="btn btn-primary float-right" id="save"><?php echo e(__('Lưu lại')); ?></button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/Admin/QuanLyTaiKhoan/themMoiTaiKhoan.blade.php ENDPATH**/ ?>