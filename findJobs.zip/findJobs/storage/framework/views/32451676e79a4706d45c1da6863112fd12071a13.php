<?php if($typeSend == 0): ?>
    <tr>
        <td><?php echo e($index); ?></td>
        <td class="project-name"><?php echo e($data['name']); ?></td>
        <td class="project-from text-center"><?php echo e($data['fromDate']); ?></td>
        <td class="project-to text-center"><?php echo e($data['toDate']); ?></td>


        <td class="project-links"><a href="<?php echo e($data['links']); ?>" target="_blank"><?php echo e($data['links']); ?></a></td>
        <td>
            <div class="btn-group btn-group-sm" style="float: none;">

                <button class="btn btn-warning btn-sm cap-nhat-project"><span class="fa fa-edit"></span></button>
                <button class="btn btn-danger btn-sm xoa1-project"><span class="fa fa-trash"></span></button>
            </div>

        </td>
    </tr>
<?php elseif($typeSend == 1): ?>
    <?php if($data['nguoi_tim_viec']['projects'] != null): ?>

        <?php $__currentLoopData = $data['nguoi_tim_viec']['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-primary"><?php echo e($row['id']); ?></td>
                <td class="project-name"><?php echo e(ucwords($row['project_name'])); ?></td>
                <td class="project-from text-center"><?php echo e($row['project_from']); ?></td>
                <td class="project-to text-center"><?php echo e($row['project_to']); ?></td>

                    














                    

                <td class="project-links"><?php echo e($row['project_links']); ?></td>
                <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                <?php else: ?>
                    <td>
                        <div class="btn-group btn-group-sm" style="float: none;">

                            <button class="btn btn-warning btn-sm cap-nhat-project"><span class="fa fa-edit"></span>
                            </button>
                            <button class="btn btn-danger btn-sm xoa1-project"><span class="fa fa-trash"></span></button>
                        </div>

                    </td>
                <?php endif; ?>


            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/User/nguoiTimViec/projectsAppend.blade.php ENDPATH**/ ?>