



<div class="modal-header">
    <h4 class="modal-title" id="exampleModalScrollableTitle">Cập nhật công ty</h4>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    
    
    
    
    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="ten_cong_ty"><abbr class="text-danger  font-15">* </abbr><?php echo e(__('Tên công ty: ')); ?>

            </label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 text-left">
            <input type="hidden" id="id-danh-sach" value="<?php echo e($data['id']); ?>">
            <input class="form-control not-null" id="ten_cong_ty" title="Tên công ty"
                   value="<?php if($data['cong_ty']['name'] != null): ?><?php echo e($data['cong_ty']['name']); ?><?php endif; ?>">
            <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="link_website"><?php echo e(__('Website: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
            <input class="form-control" id="link_website" title="Website"
                   value="<?php if($data['cong_ty']['websites'] != null): ?><?php echo e($data['cong_ty']['websites']); ?><?php endif; ?>">
        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="email_cong_ty"><abbr class="text-danger  font-15">* </abbr><?php echo e(__('Email: ')); ?>

            </label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
            <input class="form-control not-null" id="email_cong_ty" data-rule="email" title="Email"
                   value="<?php if($data['cong_ty']['email'] != null): ?><?php echo e($data['cong_ty']['email']); ?><?php endif; ?>">
            <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="dien_thoai_cong_ty"><abbr
                    class="text-danger  font-15">* </abbr><?php echo e(__('Điện thoại: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
            <input class="form-control not-null" id="dien_thoai_cong_ty" maxlength="10"
                   title="Điện thoại"
                   value="<?php if($data['cong_ty']['phone'] != null): ?><?php echo e($data['cong_ty']['phone']); ?><?php endif; ?>">
            <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="dia_chi_chinh"><?php echo e(__('Địa chỉ chính: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 text-left">
            <input class="form-control" id="dia_chi_chinh"
                   value="<?php if($data['cong_ty']['dia_chi'] != null): ?><?php echo e($data['cong_ty']['dia_chi']); ?><?php endif; ?>">
        </div>
    </div>

    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="so_luong_chi_nhanh"><?php echo e(__('Số lượng chi nhánh: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-left">
            <input class="form-control not-null <?php if($data['cong_ty']['so_chi_nhanh'] != null): ?> ready <?php endif; ?>" id="so_luong_chi_nhanh" title="Số lượng chi nhánh" readonly
                   value="<?php if($data['cong_ty']['so_chi_nhanh'] != null): ?><?php echo e($data['cong_ty']['so_chi_nhanh']); ?><?php else: ?><?php echo e(0); ?><?php endif; ?>">

            <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>

        </div>
    </div>

    <div class="row form-group d-none" id="dia_chi_chi_nhanh">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="dia_chi_chi_nhanh"><?php echo e(__('Địa chỉ chi nhánh: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 text-left" id="dia_chi_chi_nhanh_append">
            <?php if(unserialize($data['cong_ty']['dia_chi_chi_nhanh']) != null): ?>
                <?php $__currentLoopData = unserialize($data['cong_ty']['dia_chi_chi_nhanh']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input class="form-control dia_chi_chi_nhanh child-not-null" title="Địa chỉ chi nhánh"
                           value="<?php if($row !=null): ?><?php echo e($row); ?><?php endif; ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
            

            
            
            
            

        </div>
    </div>

    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label><?php echo e(__('Giờ làm việc: ')); ?></label>
        </div>
        <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 pr-md-0">
            <div class="input-group">
                <div class="input-group-append">
                    <span class="input-group-text pl-1 pr-1"><?php echo e(__('Từ')); ?></span>
                </div>

                <input class="form-control not-null" style="border-left: none" id="from_time"
                       value="<?php if(unserialize($data['cong_ty']['gio_lam_viec']) != null): ?><?php echo e(unserialize($data['cong_ty']['gio_lam_viec'])[0]); ?><?php endif; ?>">
                <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
            </div>

        </div>
        <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 pl-md-0">
            <div class="input-group">
                <div class="input-group-append">
                    <span class="input-group-text pl-0 pr-0"><?php echo e(__('Đến')); ?></span>
                </div>
                <input class="form-control not-null" style="border-left: none" id="to_time"
                       value="<?php if(unserialize($data['cong_ty']['gio_lam_viec']) != null): ?><?php echo e(unserialize($data['cong_ty']['gio_lam_viec'])[1]); ?><?php endif; ?>">
                <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>

            </div>

        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label><?php echo e(__('Ngày làm việc: ')); ?></label>
        </div>
        <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 pr-md-0 text-center">
            <div class="input-group">
                <div class="input-group-append pl-1 pr-1"
                     style="position: absolute;z-index: 1;left: -6px;">
                    <span class="input-group-text pl-1 pr-1"><?php echo e(__('Từ')); ?></span>
                </div>
                <select class="form-control text-center not-null" id="from_day" title="Ngày làm việc">
                    <option value="" selected disabled>Chọn thứ</option>
                    <option value="1"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[0] == 1): ?> selected <?php endif; ?>><?php echo e(__('Chủ nhật')); ?></option>
                    <option value="2"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[0] == 2): ?> selected <?php endif; ?>><?php echo e(__('Thứ hai')); ?></option>
                    <option value="3"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[0] == 3): ?> selected <?php endif; ?>><?php echo e(__('Thứ ba')); ?></option>
                    <option value="4"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[0] == 4): ?> selected <?php endif; ?>><?php echo e(__('Thứ tư')); ?></option>
                    <option value="5"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[0] == 5): ?> selected <?php endif; ?>><?php echo e(__('Thứ năm')); ?></option>
                    <option value="6"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[0] == 6): ?> selected <?php endif; ?>><?php echo e(__('Thứ sáu')); ?></option>
                    <option value="7"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[0] == 7): ?> selected <?php endif; ?>><?php echo e(__('Thứ bảy')); ?></option>
                    <option value="8"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[0] == 8): ?> selected <?php endif; ?>><?php echo e(__('Sáng - Thứ bảy')); ?></option>
                </select>
                <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
            </div>

        </div>
        <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 pl-md-0 text-center">
            <div class="input-group">
                <div class="input-group-append pl-1 pr-1"
                     style="position: absolute;z-index: 1;left: -6px;">
                    <span class="input-group-text pl-0 pr-0"><?php echo e(__('Đến')); ?></span>
                </div>
                <select class="form-control not-null" id="to_day" title="Ngày làm việc">
                    <option value="" selected disabled>Chọn thứ</option>
                    <option value="1"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[1] == 1): ?> selected <?php endif; ?>><?php echo e(__('Chủ nhật')); ?></option>
                    <option value="2"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[1] == 2): ?> selected <?php endif; ?>><?php echo e(__('Thứ hai')); ?></option>
                    <option value="3"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[1] == 3): ?> selected <?php endif; ?>><?php echo e(__('Thứ ba')); ?></option>
                    <option value="4"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[1] == 4): ?> selected <?php endif; ?>><?php echo e(__('Thứ tư')); ?></option>
                    <option value="5"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[1] == 5): ?> selected <?php endif; ?>><?php echo e(__('Thứ năm')); ?></option>
                    <option value="6"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[1] == 6): ?> selected <?php endif; ?>><?php echo e(__('Thứ sáu')); ?></option>
                    <option value="7"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[1] == 7): ?> selected <?php endif; ?>><?php echo e(__('Thứ bảy')); ?></option>
                    <option value="8"
                            <?php if(unserialize($data['cong_ty']['ngay_lam_viec']) != null && unserialize($data['cong_ty']['ngay_lam_viec'])[1] == 8): ?> selected <?php endif; ?>><?php echo e(__('Sáng - Thứ bảy')); ?></option>
                </select>
                
                <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
            </div>

        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="quy_mo_nhan_su"><?php echo e(__('Quy mô nhân sự: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 text-left">
            <select class="form-control not-null" id="quy_mo_nhan_su" title="Quy mô nhân sự">

                <option disabled selected value="">Quy mô nhân sự</option>
                <option value="1" <?php if($data['cong_ty']['so_nhan_vien'] != null && $data['cong_ty']['so_nhan_vien'] == 1): ?> selected <?php endif; ?>>
                    Dưới 20 người
                </option>
                <option value="2" <?php if($data['cong_ty']['so_nhan_vien'] != null && $data['cong_ty']['so_nhan_vien'] == 2): ?> selected <?php endif; ?>>
                    Từ 20 đến 50 người
                </option>
                <option value="3" <?php if($data['cong_ty']['so_nhan_vien'] != null && $data['cong_ty']['so_nhan_vien'] == 3): ?> selected <?php endif; ?>>
                    Từ 50 đến 75 người
                </option>
                <option value="4" <?php if($data['cong_ty']['so_nhan_vien'] != null && $data['cong_ty']['so_nhan_vien'] == 4): ?> selected <?php endif; ?>>
                    Trên 75 người
                </option>
            </select>
            <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
        </div>
    </div>

    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="linh_vuc_hoat_dong"><abbr
                    class="text-danger  font-15">* </abbr><?php echo e(__('Lĩnh vực: ')); ?>

            </label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 text-left">

            <select id="linh_vuc_hoat_dong" class="form-control not-null" multiple="multiple"
                    tabindex="-1"
                    title="Lĩnh vực"
                    aria-hidden="true">
                <option value="" disabled>Ngành Nghề</option>
                <?php $__currentLoopData = $data['nganh_nghe']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row['id']); ?>"
                            <?php if(count($data['mang_nganh_nghe']) != 0 && in_array($row['id'],$data['mang_nganh_nghe']) == true): ?> selected <?php endif; ?>><?php echo e($row['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>

        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="fax_cong_ty"><?php echo e(__('FAX: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
            <input class="form-control" id="fax_cong_ty" value="<?php if($data['cong_ty']['fax'] != null): ?><?php echo e($data['cong_ty']['fax']); ?><?php endif; ?>">
        </div>
    </div>

    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="nam_thanh_lap"><?php echo e(__('Năm thành lập: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
            <input class="form-control" id="nam_thanh_lap" value="<?php if($data['cong_ty']['nam_thanh_lap'] != null): ?><?php echo e($data['cong_ty']['nam_thanh_lap']); ?><?php endif; ?>">
        </div>
    </div>

    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="logo_cong_ty"><?php echo e(__('Giới thiệu công ty: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 center-element position-relative">
            <textarea class="form-control not-null break-custom" id="gioi_thieu_cong_ty"><?php if($data['cong_ty']['gioi_thieu'] != null): ?><?php echo e($data['cong_ty']['gioi_thieu']); ?><?php endif; ?></textarea>
        </div>
    </div>

    <div class="row form-group">
        <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
            <label for="logo_cong_ty"><?php echo e(__('Logo: ')); ?></label>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 center-element position-relative">
            <div style="width: 8rem;height: 8rem;" id="logo_cong_ty">
                <img
                    src="<?php if($data['cong_ty']['logo'] != null): ?><?php echo e(URL::asset(''.$data['cong_ty']['logo'].'')); ?><?php else: ?><?php echo e(URL::asset('images/default-company-logo.jpg')); ?><?php endif; ?>"
                    class="avatar-xl img-thumbnail"
                    data-data="<?php if($data['cong_ty']['logo'] != null): ?><?php echo e(URL::asset(''.$data['cong_ty']['logo'].'')); ?><?php else: ?><?php echo e(URL::asset('images/default-company-logo.jpg')); ?><?php endif; ?>"
                    alt="profile-image" tabindex="-1" style="width: 100%;height: 100%">
                <div class="position-absolute hover-me"
                     style="display:none;width: 8rem;height: 8rem;top:0">
                    <div class="position-relative center-element"
                         style="width: 100%;height: 100%;background-color: rgba(50, 58, 70, .55)">
                        <div>
                            <div class="row mt-1 mb-1">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
                                    <button class="btn btn-success btn-sm logo_cong_ty_change">Đổi ảnh</button>
                                    <input type="file" class="d-none logo_cong_ty_file">
                                </div>
                            </div>
                            <div class="row mt-1 mb-1">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
                                    <button class="btn btn-light btn-sm logo_cong_ty_view">Xem ảnh</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="row mt-1 mb-1 d-block d-md-none">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
                        <button class="btn btn-success btn-sm logo_cong_ty_change">Đổi ảnh</button>
                    </div>
                </div>
                <div class="row mt-1 mb-1 d-block d-md-none">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
                        <button class="btn btn-light btn-sm logo_cong_ty_view">Xem ảnh</button>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
    <button type="button" class="btn btn-primary" id="save-cong-ty">Lưu lại</button>
</div>



<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/CongTy/modal/capNhat.blade.php ENDPATH**/ ?>