<?php $__env->startSection('content'); ?>
    <head>
        
        

        <link href="<?php echo e(URL::asset('assets\libs\multiselect\multi-select.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\select2\select2.min.css')); ?>" rel="stylesheet" type="text/css">
        <!-- Lightbox css -->
        <link href="<?php echo e(URL::asset('assets\libs\magnific-popup\magnific-popup.css')); ?>" rel="stylesheet" type="text/css">
        
        
        


    </head>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item active">Tìm kiếm nhà tuyển dụng</li>
                    </ol>
                </div>
                <h4 class="page-title">Tìm kiếm nhà tuyển dụng</h4>
            </div>
        </div>
    </div>

    <div class="card-box">
        <form method="get" action="">
            <?php echo csrf_field(); ?>
            <div class="row">






                <div class="col-sm-3 col-md-3">
                    <div class="row">
                        <select class="col-sm-12 col-md-12 form-control" id="nganh_nghe" name="nganh_nghe">
                            <option value="">Tất cả ngành nghề</option>
                            <?php $__currentLoopData = $data['nganh_nghe']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($row['id']); ?>" <?php if(Request::exists('nganh_nghe') && Request::get('nganh_nghe') != null && Request::get('nganh_nghe') == $row['id']): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($row['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                </div>
                <div class="col-sm-3 col-md-3">
                    <div class="row">
                        <select class="col-sm-12 col-md-12 form-control" id="dia_diem" name="dia_diem">
                            <option value="">Tất cả địa điểm</option>
                            <?php $__currentLoopData = $data['dia_diem']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($row['id']); ?>" <?php if(Request::exists('dia_diem') && Request::get('dia_diem') != null && Request::get('dia_diem') == $row['id']): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($row['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-sm-2 col-md-2">
                    <button type="submit" class="btn btn-primary">Tìm kiếm</button>
                </div>
            </div>
        </form>
    </div>
    <div class="card-box">
        <div class="row filterable-content">

            <?php if(count($dataNhaTuyenDung) > 0): ?>
                
                <?php $__currentLoopData = $dataNhaTuyenDung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-xl-3 filter-item all web illustrator">
                        <div class="gal-box">
                            <a href="<?php echo e(route('nhatuyendung.chiTietNhaTuyenDung',['nha_tuyen_dung'=>$row['id']])); ?>">
                                <img
                                    src="<?php if(isset($row['get_cong_ty']['logo']) && $row['get_cong_ty']['logo'] != null): ?><?php echo e(URL::asset($row['get_cong_ty']['logo'])); ?><?php else: ?><?php echo e(URL::asset('images/default-company-logo.jpg')); ?><?php endif; ?>"
                                    class="img-fluid">
                            </a>
                            <div class="gall-info">
                                <h4 class="font-16 mt-0"
                                    title="<?php if(isset($row['get_cong_ty']['name']) && $row['get_cong_ty']['name'] != null): ?><?php echo e($row['get_cong_ty']['name']); ?><?php endif; ?>"
                                    style="text-transform: uppercase"><?php if(isset($row['get_cong_ty']['name']) && $row['get_cong_ty']['name'] != null): ?><?php echo e($row['get_cong_ty']['name']); ?><?php endif; ?></h4>
                                <a>
                                    <img
                                        src="<?php if(isset($row['get_tai_khoan']['avatar']) && $row['get_tai_khoan']['avatar'] != null): ?><?php echo e(URL::asset($row['get_tai_khoan']['avatar'])); ?><?php else: ?><?php echo e(URL::asset('images/default-user-icon-8.jpg')); ?><?php endif; ?>"
                                        alt="user-img" class="rounded-circle d-none" height="24">
                                    <span
                                        class="text-muted ml-1 text-capitalize" style="font-size: 0px"><?php if(isset($row['get_tai_khoan']['ho_ten']) && $row['get_tai_khoan']['ho_ten'] != null): ?><?php echo e($row['get_tai_khoan']['ho_ten']); ?><?php endif; ?></span>
                                </a>
                                <p class="text-center mb-0"><?php if(isset($row['get_bai_viet']) && $row['get_bai_viet'] != null): ?><?php echo e(count($row['get_bai_viet'])." việc đang tuyển"); ?><?php else: ?>
                                        <span class="text-danger"><?php echo e("Chưa có bài tuyển dụng"); ?></span> <?php endif; ?></p>
                                
                                
                            </div> <!-- gallery info -->
                        </div> <!-- end gal-box -->
                    </div> <!-- end col -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php else: ?>
                <?php echo e("Không tìm thấy nhà tuyển dụng nào"); ?>

            <?php endif; ?>

        </div>
        <div class="row filterable-content">
            <?php if(count($dataNhaTuyenDung) > 0): ?>
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <?php echo e($dataNhaTuyenDung->links()); ?>

                    </div>
                </div>
            <?php endif; ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(URL::asset('assets\libs\multiselect\jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\jquery-quicksearch\jquery.quicksearch.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\select2\select2.min.js')); ?>"></script>
    <!-- Magnific Popup-->
    

    <!-- Gallery Init-->
    
    <script>
        $(function () {
            select2Default($('#nganh_nghe'));
            select2Default($('#dia_diem'));
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/TimKiemNhaTuyenDung/index.blade.php ENDPATH**/ ?>