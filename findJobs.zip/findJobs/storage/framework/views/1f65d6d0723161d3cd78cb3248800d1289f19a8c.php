<?php $__env->startSection('content'); ?>
    <head>
        <link href="<?php echo e(URL::asset('assets\libs\quill\quill.core.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\quill\quill.bubble.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\quill\quill.snow.css')); ?>" rel="stylesheet" type="text/css">

        <link href="<?php echo e(URL::asset('assets\libs\bootstrap-touchspin\jquery.bootstrap-touchspin.min.css')); ?>"
              rel="stylesheet">

        <link href="<?php echo e(URL::asset('assets\libs\multiselect\multi-select.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\select2\select2.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\bootstrap-datepicker\bootstrap-datepicker.min.css')); ?>" rel="stylesheet"
              type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\sweetalert2\sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css">





    </head>

    <?php echo $__env->make('BaiViet.modal.xemTruoc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('CongTy.modal.themMoi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('CongTy.modal.xemAnhDaiDien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">

                        <li class="breadcrumb-item"><a>Quản lý tuyển dụng</a></li>
                        <li class="breadcrumb-item active"><?php echo e(__('Đăng bài tuyển dụng')); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e(__('Đăng Bài Tuyển Dụng')); ?></h4>
            </div>
        </div>
    </div>

    <?php echo $__env->make('BaiViet.contentBaiDang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row card-box p-2">
        <div class="col-sm-12 col-md-12">
            <?php echo $__env->make('BaiViet.buttonDangBai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>
    <?php echo $__env->make('CongTy.modal.anh_dai_dien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(URL::asset('assets\libs\multiselect\jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\jquery-quicksearch\jquery.quicksearch.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\select2\select2.min.js')); ?>"></script>

    <script src="<?php echo e(URL::asset('assets\libs\bootstrap-datepicker\bootstrap-datepicker.min.js')); ?>"></script>

    <script type="text/javascript"
            src="<?php echo e(URL::asset('assets\libs\date-time-picker\moment-with-locales.min.js')); ?>"></script>

    <link rel="stylesheet" type="text/css"
          href="<?php echo e(asset('assets\libs\date-time-picker\bootstrap-datetimepicker.css')); ?>">
    <script type="text/javascript"
            src="<?php echo e(URL::asset('assets\libs\date-time-picker\bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\bootstrap-touchspin\jquery.bootstrap-touchspin.min.js')); ?>"></script>

    <!-- Plugins js -->

    <script src="<?php echo e(URL::asset('assets\libs\quill\quill.min.js')); ?>"></script>







    <!-- Core build with no theme, formatting, non-essential modules -->



    <!-- Init js-->






    <!-- Init js-->

    <script type="text/javascript"
            src="<?php echo e(URL::asset('assets\libs\date-time-picker\moment-with-locales.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets\libs\sweetalert2\sweetalert2.min.js')); ?>"></script>
    <script type="text/javascript">

        var quill = new Quill("#mo-ta-editor", {
            theme: "snow",
            // placeholder: 'Compose an epic...',
            modules: {toolbar: [ ["bold", "italic", "underline"], [{list: "ordered"}, {list: "bullet"}], [{align: []}], [], ["clean"]]}
        });
        var quill2 = new Quill("#yeu-cau-editor", {
            theme: "snow",
            // placeholder: 'Compose an epic...',
            modules: {toolbar: [ ["bold", "italic", "underline"], [{list: "ordered"}, {list: "bullet"}], [{align: []}], [], ["clean"]]}
        });
        var quill3 = new Quill("#quyen-loi-editor", {
            theme: "snow",
            // placeholder: 'Compose an epic...',
            modules: {toolbar: [ ["bold", "italic", "underline"], [{list: "ordered"}, {list: "bullet"}], [{align: []}], [], ["clean"]]}
        });

        $(document).on('focusout','.custom-editor .ql-editor',function () {
            let __this = $(this);
            let value = $(this).html();
            let __parent = $(this).parents('.custom-editor').parent();

            if ($.trim(__this.text()).length == 0){
                __this.html("");
            }
            if ($.trim(__this.text()).length == 0){
                __parent.find('textarea').addClass('is-invalid');
                __parent.find('textarea').parent().find('.invalid-feedback').addClass('text-left').find('strong').text(__parent.find('textarea').attr('title') + ' không được để trống');
            }else{
                __parent.find('textarea').removeClass('is-invalid');
            }
            __parent.find('textarea').val(""+value+"");
        });
        // let customeditor =$('body').find('.custom-editor');
        // if (customeditor != undefined && customeditor.length > 0){
        //     customeditor.each(function () {
        //         new Quill('#'+$(this).attr(), {
        //             theme: "snow",
        //             // placeholder: 'Compose an epic...',
        //             modules: {toolbar: [ ["bold", "italic", "underline"], [{list: "ordered"}, {list: "bullet"}], [{align: []}], [], ["clean"]]}
        //         });            })
        // }
        // console.log($('body').find('.custom-editor').length)
        // mo_ta_cong_viec
        //
        // var quill = new Quill("#snow-editor", {
        //     theme: "snow",
        //     modules: {toolbar: [[{font: []}, {size: []}], ["bold", "italic", "underline", "strike"], [{color: []}, {background: []}], [{script: "super"}, {script: "sub"}], [{header: [!1, 1, 2, 3, 4, 5, 6]}, "blockquote", "code-block"], [{list: "ordered"}, {list: "bullet"}, {indent: "-1"}, {indent: "+1"}], ["direction", {align: []}], ["link", "image", "video", "formula"], ["clean"]]}
        // });
        // var editor = new Quill('#editor', {
        // //     modules: { toolbar: '#toolbar' },
        //     theme: 'bubble'
        // });\
        // var quill = new Quill('#editor', {
        //     modules: {
        //         toolbar: [
        //             // [{ header: [2, 2, false] }],
        //             ['bold', 'italic', 'underline'],
        //             ['align']
        //         ]
        //     },
        //     placeholder: 'Compose an epic...',
        //     theme: 'snow'  // or 'bubble'
        // });
        // quill = new Quill("#bubble-editor", {theme: "bubble"});
        // new Quill('#' + uid, options);
        let table = null;
        let HTMLcongTy = null;
        let getBaseURL = '<?php echo e(URL::asset('/')); ?>';
        const initEventCapNhatCongTy = ()=>{
            $('#doi_anh_dai_dien').data('type','them-moi-cong-ty')
            select2Default($('select#from_day'));
            select2Default($('select#to_day'));
            select2Default($('select#quy_mo_nhan_su'));
            select2Default($('select#dia_diem'));
            select2MultipleDefault($('select#linh_vuc_hoat_dong'),'Chọn Ngành nghề')
            // $('select#from_day,select#to_day,select#quy_mo_nhan_su').select2({
            //     dropdownParent: $('div#cap-nhat-cong-ty ')
            // });
            // $('select#linh_vuc_hoat_dong').select2({
            //     placeholder: ' Chọn Ngành nghề',
            //     allowClear: false
            // });

            $("#so_luong_chi_nhanh").TouchSpin({
                min: 0,
                buttondown_class: "btn btn-primary waves-effect",
                buttonup_class: "btn btn-primary waves-effect"
            });
            lichNam($('#nam_thanh_lap'));

            $('#from_time,#to_time').datetimepicker({
                format: 'HH:mm',
                widgetPositioning: {
                    vertical: 'bottom',
                    horizontal: 'right'
                },
                icons: {
                    time: "icofont icofont-clock-time",
                    date: "icofont icofont-ui-calendar",
                    up: "icofont icofont-rounded-up",
                    down: "icofont icofont-rounded-down",
                    next: "icofont icofont-rounded-right",
                    previous: "icofont icofont-rounded-left"
                },
            });
            hoverEventLogo();
        }
        const hoverEventLogo = () => {
            $("div#logo_cong_ty").hover(function () {
                if ($(window).width() >= 576) {
                    $(this).find('div.hover-me').fadeIn('fast');
                }
            }, function () {
                if ($(window).width() >= 576) {
                    $(this).find('div.hover-me').fadeOut('fast');
                }
            });
        }
    </script>



    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\date-picker-vi.js')); ?>"></script>

    <?php echo $__env->make('BaiViet.scriptThemMoi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/BaiViet/index.blade.php ENDPATH**/ ?>