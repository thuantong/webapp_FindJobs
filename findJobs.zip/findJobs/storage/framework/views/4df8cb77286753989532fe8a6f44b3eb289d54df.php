<script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\nhaTuyenDung_dang_bai.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\themMoiCongTy.js')); ?>"></script>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/BaiViet/scriptThemMoi.blade.php ENDPATH**/ ?>