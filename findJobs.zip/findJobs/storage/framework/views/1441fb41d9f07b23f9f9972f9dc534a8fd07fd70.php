<?php $__env->startSection('content'); ?>
    <head>
        
        

        <link href="<?php echo e(URL::asset('assets\libs\multiselect\multi-select.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\select2\select2.min.css')); ?>" rel="stylesheet" type="text/css">
        <!-- Lightbox css -->
        <link href="<?php echo e(URL::asset('assets\libs\magnific-popup\magnific-popup.css')); ?>" rel="stylesheet" type="text/css">
        
        
        


    </head>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item active">Chi tiết nhà tuyển dụng</li>
                    </ol>
                </div>
                <h4 class="page-title">Chi tiết nhà tuyển dụng</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card-box  p-1 mb-1" >
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <h4 class="tieu_de p-1 m-0 text-center bg-light text-uppercase"
                            id="ten_cong_ty"><?php if($data['get_cong_ty'] != null): ?> <?php if($data['get_cong_ty']['name'] != null): ?><?php echo e($data['get_cong_ty']['name']); ?><?php endif; ?> <?php endif; ?></h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-2 col-md-2">
                        <img
                            src="<?php if($data['get_cong_ty']['logo'] != null): ?><?php echo e(URL::asset(''.$data['get_cong_ty']['logo'].'')); ?><?php endif; ?>"
                            class="border" style="width: calc(100%)">

                    </div>
                    <div class="col-sm-6 col-md-6">
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <i>
                                    <?php if($data['cong_ty_nganh_nghe'] != null): ?>
                                        <?php echo e(implode(' - ', array_map(function($c) {
                                                return $c['name'];
                                            }, $data['cong_ty_nganh_nghe']))); ?>

                                    <?php endif; ?>
                                </i>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <span class="fa fa-globe"></span><span>
                                        <?php if($data['get_cong_ty'] != null): ?>
                                        <?php echo e($data['get_cong_ty']['websites']); ?>

                                    <?php endif; ?>
                                    </span>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <span class="icofont icofont-location-pin"></span><span>
                                        <?php if($data['get_cong_ty'] != null): ?>
                                        <?php echo e($data['get_cong_ty']['dia_chi']); ?>

                                    <?php endif; ?>
                                    </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <span class="fa fa-group"></span><span>
                                <?php if($data['get_cong_ty'] != null): ?>
                                        <?php echo e($data['quy_mo_nhan_su']['name']); ?>

                                    <?php endif; ?>
                                 </span>
                            </div>
                        </div>

                        <?php if(intval(Session::get('loai_tai_khoan')) == 1): ?>
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
                                    <div
                                        class="btn quan-tam-nha-tuyen-dung <?php if(in_array($data['id'],$data['nha_tuyen_dung_da_quan_tam']['data']) == true): ?> btn-info like-animation <?php else: ?> btn-outline-info <?php endif; ?> waves-effect position-relative"
                                        id="quan-tam-nha-tuyen-dung"
                                        data-id="<?php if($data['id'] != null): ?><?php echo e($data['id']); ?><?php endif; ?>">
                                        <i class="icofont icofont-thumbs-up"><?php if(in_array($data['id'],$data['nha_tuyen_dung_da_quan_tam']['data']) == true): ?><?php echo e(' Đã quan tâm'); ?><?php else: ?><?php echo e(' Quan tâm'); ?><?php endif; ?></i>
                                        <span class="badge badge-danger noti-icon-badge position-absolute"
                                              style="right: 0px"><?php echo e($data['nha_tuyen_dung_da_quan_tam']['total']); ?></span>
                                    </div>
                                    
                                    
                                </div>












                            </div>
                        <?php endif; ?>

                    </div>

                </div>
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <label class="mb-0">Giới thiệu:</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <span class="">
                                        <?php if($data['get_cong_ty'] != null): ?>
                                        
                                        <?php echo e($data['get_cong_ty']['gioi_thieu']); ?>

                                        

                                    <?php endif; ?>
                                    </span>
                                
                            </div>

                        </div>








                    </div>
                </div>
            </div>
        </div>
    </div>

































































































































































    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card-box  p-1 mb-1">
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <h5 class="bg-light text-center p-1"><?php echo e(__('Việc làm đang tuyển dụng')); ?><span>(</span><?php if(count($data['get_bai_viet']) != 0): ?><?php echo e(count($data['get_bai_viet'])); ?><?php else: ?><?php echo e(0); ?><?php endif; ?><span>)</span></h5>
                    </div>
                </div>
                <div class="row" style="margin-left: 0;margin-right: 0">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 bg-light">
                        
                        <div class="row" id="container-items">
                            <?php if(count($data['get_bai_viet']) != 0): ?>
                                

                                <?php $__currentLoopData = $data['get_bai_viet']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 bg-white ribbon-box iteam-click" data-id="<?php echo e($row['id']); ?>">
                                        <div class="row">
                                            <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 p-0 center-element">

                                                <img src="<?php echo e(URL::asset($row['get_cong_ty']['logo'])); ?>" class="border" style="width: calc(100%)">

                                            </div>
                                            <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10 text-center">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text"><h5 class="mb-0"><a class="xem-chi-tiet-post" href="<?php echo e(route('baiviet.getThongTinBaiViet',[$row['id'],'chitiet'=>1])); ?>"><span title="<?php echo e(ucwords($row['tieu_de'])); ?>"><?php echo e(ucwords($row['tieu_de'])); ?></span></a>
                                                        </h5></div>
                                                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text"><i><span title="<?php echo e($row['get_cong_ty']['name']); ?>"><?php echo e($row['get_cong_ty']['name']); ?></span></i>
                                                    </div>
                                                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                                        <div class="row">
                                                            <div class="col-sm-4 col-md-4 col-xl-4 text"><span title="<?php echo e($row['luong_from']); ?><?php echo e(' - '); ?><?php echo e($row['luong_to']); ?><?php echo e(' Triệu'); ?>"><span class="icofont icofont-money"></span><?php echo e($row['luong_from']); ?><?php echo e(' - '); ?><?php echo e($row['luong_to']); ?><?php echo e(' Triệu'); ?></span></div>
                                                            <div class="col-sm-4 col-md-4 col-xl-4 text"><span title="<?php echo e($row['get_dia_diem']['name']); ?>"><span class="icofont icofont-location-pin"></span><?php echo e($row['get_dia_diem']['name']); ?></span></div>
                                                            <div class="col-sm-4 col-md-4 col-xl-4 text"><span title="<?php echo e($row['han_tuyen']); ?>"><span class="fa fa-calendar-plus-o"></span><?php echo e($row['han_tuyen']); ?></span></div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if(intval($row['isHot']) == 1): ?>
                                            <div class="ribbon-two ribbon-two-danger floats-right"><span class="right-custom">Hot</span>
                                            </div>
                                        <?php endif; ?>
                                        <div class="arrow-item d-none"></div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="row">
                                    <div class="col-sm-12 col-md-12 bg-primary text-white text-center">
                                        <?php echo e(__('Không tìm thấy việc làm')); ?>

                                    </div>
                                </div>
                                
                            <?php endif; ?>
                            <?php $__env->startPush('scripts'); ?>
                                <script type="text/javascript">
                                    $(function () {
                                        //search
                                        let widthImage_search = $('#container-items .iteam-click').find('img').parent().width();
                                        let heightImage_search = widthImage_search;
                                        $('#container-items .iteam-click').find('img').css('width', widthImage_search).css('height', heightImage_search);
                                        $(window).resize(function () {
                                            widthImage_search = $('#container-items .iteam-click').find('img').parent().width();
                                            heightImage_search = widthImage_search;
                                            // console.log($('.iteam-click').find('img').parent().width());
                                            $('#container-items .iteam-click').find('img').css('width', widthImage_search).css('height', heightImage_search);

                                        });
                                        // //container index
                                        // let widthImage = $('#container-items .iteam-click').find('img').parent().width();
                                        // let heightImage = widthImage;
                                        //
                                        // $('#container-items .iteam-click').find('img').css('width', widthImage).css('height', heightImage);
                                        // //mũi tên
                                        // $('#container-items .iteam-click').on('click', function () {
                                        //     // console.log($(this).height());
                                        //     let haflHeight = parseFloat($(this).height())*0.4;
                                        //     $(this).find('.arrow-item').css('top',haflHeight+'px');
                                        //     if($(document).width() >= 576){
                                        //         $('#container-items .iteam-click').removeClass('iteam-click-focus');
                                        //         $(this).addClass('iteam-click-focus');
                                        //         $('.arrow-item').addClass('d-none');
                                        //         $(this).find('.arrow-item').removeClass('d-none');
                                        //     }else if($(document).width() < 576){
                                        //         $('.arrow-item').addClass('d-none');
                                        //     }
                                        // });
                                        // //resize post
                                        // $(window).resize(function () {
                                        //     widthImage = $('#container-items .iteam-click').find('img').parent().width();
                                        //     heightImage = widthImage;
                                        //     $('#container-items .iteam-click').find('img').css('width', widthImage).css('height', heightImage);
                                        //     console.log('cái con cặc')
                                        // });
                                    })
                                </script>
                            <?php $__env->stopPush(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(URL::asset('assets\libs\multiselect\jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\jquery-quicksearch\jquery.quicksearch.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\select2\select2.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/chiTietNhaTuyenDung/index.blade.php ENDPATH**/ ?>