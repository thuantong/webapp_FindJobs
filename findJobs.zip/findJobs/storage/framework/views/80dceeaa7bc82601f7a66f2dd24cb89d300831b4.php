<?php $__env->startSection('content'); ?>
    <head>
        <link href="<?php echo e(URL::asset('assets\libs\multiselect\multi-select.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\select2\select2.min.css')); ?>" rel="stylesheet" type="text/css">
        <!-- ION Slider -->
        <link href="<?php echo e(URL::asset('assets\libs\ion-rangeslider\ion.rangeSlider.css')); ?>" rel="stylesheet" type="text/css">
        
        <link href="<?php echo e(URL::asset('assets\libs\bootstrap-touchspin\jquery.bootstrap-touchspin.min.css')); ?>"
              rel="stylesheet">
        <link href="<?php echo e(URL::asset('assets\libs\sweetalert2\sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css">

        
        <link href="<?php echo e(URL::asset('assets\libs\bootstrap-datepicker\bootstrap-datepicker.min.css')); ?>" rel="stylesheet"
              type="text/css">
    </head>
    <?php echo $__env->make('BaoCao.modalBaoCao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="page-title-box mb-1">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="/">Việc làm</a></li>
                        <li class="breadcrumb-item active">Xem chi tiết</li>
                    </ol>
                </div>
                <h4 class="page-title">Xem chi tiết việc làm</h4>


                

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card-box  p-1 mb-1">
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <h4 class="tieu_de p-1 m-0 text-center bg-light text-uppercase"
                            id="ten_cong_ty"><?php if($data['get_cong_ty'] != null): ?> <?php if($data['get_cong_ty']['name'] != null): ?><?php echo e($data['get_cong_ty']['name']); ?><?php endif; ?> <?php endif; ?></h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-2 col-md-2">
                        <img
                            src="<?php if($data['get_cong_ty']['logo'] != null): ?><?php echo e(URL::asset(''.$data['get_cong_ty']['logo'].'')); ?><?php endif; ?>"
                            class="border" style="width: calc(100%)">

                    </div>
                    <div class="col-sm-4 col-md-4">
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <i>
                                    <?php if($data['cong_ty_nganh_nghe'] != null): ?>
                                        <?php echo e(implode(' - ', array_map(function($c) {
                                                return $c['name'];
                                            }, $data['cong_ty_nganh_nghe']))); ?>

                                    <?php endif; ?>
                                </i>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <span class="fa fa-globe"></span><span>
                                        <?php if($data['get_cong_ty'] != null): ?>
                                        <?php echo e($data['get_cong_ty']['websites']); ?>

                                    <?php endif; ?>
                                    </span>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <span class="icofont icofont-location-pin"></span><span>
                                        <?php if($data['get_cong_ty'] != null): ?>
                                        <?php echo e($data['get_cong_ty']['dia_chi']); ?>

                                    <?php endif; ?>
                                    </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <span class="fa fa-group"></span><span>
                                <?php if($data['get_cong_ty'] != null): ?>
                                        <?php echo e($data['quy_mo_nhan_su']['name']); ?>

                                    <?php endif; ?>
                                 </span>
                            </div>
                        </div>

                        <?php if(intval(Session::get('loai_tai_khoan')) == 1): ?>
                            <div class="row">
                                <div class="col-sm-12 col-md-6 text-left">
                                    <div
                                        class="btn quan-tam-nha-tuyen-dung mt-2  <?php if(in_array($data['get_nha_tuyen_dung']['id'],$data['nha_tuyen_dung_da_quan_tam']['data']) == true): ?> btn-info like-animation <?php else: ?> btn-outline-info <?php endif; ?> waves-effect position-relative"
                                        id="quan-tam-nha-tuyen-dung"
                                        data-id="<?php if($data['get_nha_tuyen_dung']['id'] != null): ?><?php echo e($data['get_nha_tuyen_dung']['id']); ?><?php endif; ?>">
                                        <i class="icofont icofont-thumbs-up"><?php if(in_array($data['get_nha_tuyen_dung']['id'],$data['nha_tuyen_dung_da_quan_tam']['data']) == true): ?><?php echo e(' Đã quan tâm'); ?><?php else: ?><?php echo e(' Quan tâm'); ?><?php endif; ?></i>
                                        <span class="badge badge-danger noti-icon-badge position-absolute"
                                              style="right: 0px"><?php echo e($data['nha_tuyen_dung_da_quan_tam']['total']); ?></span>
                                    </div>
                                    
                                    
                                </div>
                                    <div class="col-sm-12 col-md-6 text-left">
                                        <button
                                            class="btn mt-2 <?php if(in_array($data['get_nha_tuyen_dung']['id'],$data['bao_cao']['data']) == false): ?> btn-outline-primary <?php else: ?> btn-primary like-animation <?php endif; ?> waves-effect bao-cao-button-call"
                                            <?php if(in_array($data['get_nha_tuyen_dung']['id'],$data['bao_cao']['data']) == false): ?> id="bao-cao-button-call" <?php endif; ?>
                                        ><i
                                                class="fa fa-exclamation"></i><?php if(in_array($data['get_nha_tuyen_dung']['id'],$data['bao_cao']['data'])): ?><?php echo e(__(' Đã báo cáo')); ?><?php else: ?><?php echo e(__(' Báo cáo')); ?><?php endif; ?>
                                        </button>
                                    </div>

                            </div>
                        <?php endif; ?>

                    </div>
                    <div class="col-sm-6 col-md-6">
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <label class="mb-0">Giới thiệu:</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 overflow-hidden" style="max-height: 20vh">
                                <span class="">
                                        <?php if($data['get_cong_ty'] != null): ?>
                                        
                                        <?php echo e($data['get_cong_ty']['gioi_thieu']); ?>

                                        

                                    <?php endif; ?>
                                    </span>
                                
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 text-left">

                                <a href="<?php echo e(route('nhatuyendung.chiTietNhaTuyenDung',['nha_tuyen_dung'=>$data['get_nha_tuyen_dung']['id'] ])); ?>" class="btn-sm btn btn-default text-primary p-0">[Xem chi tiết]</a>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card-box p-1 mb-1">

                <div class="row" id="container-section">
                    <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                <div class="form-group row">
                                    <label class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-center">
                                        <h4 class="tieu_de bg-light p-1 m-0 text-capitalize"
                                            id="tieu_de"><?php if($data['tieu_de'] != null): ?><?php echo e($data['tieu_de']); ?><?php endif; ?></h4>
                                    </label>

                                </div>

                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                

                                
                                <?php if(intval(Session::get('loai_tai_khoan')) == 1): ?>
                                    <div class="form-group row">

                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 pt-1 pb-1">
                                            <div class="row center-element text-center">
                                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                                    <div
                                                        class="btn <?php if(in_array($data['id'],$data['bai_da_luu']['data']) == true): ?> btn-primary like-animation <?php else: ?> btn-outline-primary <?php endif; ?> waves-effect position-relative"
                                                        id="trang-chu-like-post" data-id="<?php echo e($data['id']); ?>">
                                                        <i class="icofont icofont-thumbs-up"><?php if(in_array($data['id'],$data['bai_da_luu']['data'])): ?><?php echo e(' Đã lưu'); ?><?php else: ?><?php echo e(' Lưu bài'); ?><?php endif; ?></i>
                                                        <span
                                                            class="badge badge-danger noti-icon-badge position-absolute"
                                                            style="right: 0px"><?php echo e($data['bai_da_luu']['total']); ?></span>
                                                    </div>
                                                    
                                                    
                                                    
                                                    





                                                    <div
                                                        class="btn <?php if(in_array($data['id'],$data['don_xin_viec']['data']) == false): ?> btn-outline-warning <?php else: ?> btn-warning like-animation <?php endif; ?> waves-effect position-relative call-modal-nop-don"
                                                        <?php if(in_array($data['id'],$data['don_xin_viec']['data']) == false): ?> id="call-modal-nop-don" <?php endif; ?>>
                                                        <i class="fa fa-send"><?php if(in_array($data['id'],$data['don_xin_viec']['data'])): ?><?php echo e(' Đã ứng tuyển'); ?><?php else: ?><?php echo e(' Nộp đơn'); ?><?php endif; ?></i>
                                                        

                                                    </div>



                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="row">
                                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 pl-3 pr-3">
                                        <div class="form-group row">
                                            <h4
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">
                                                <u>Mô
                                                    tả công việc:</u></h4>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12" id="mo_ta_cong_viec">
                                                <?php if($data['mo_ta'] != null): ?><?php echo $data['mo_ta']; ?><?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <h4
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">
                                                <u>Yêu
                                                    cầu công việc</u></h4>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12" id="yeu_cau_cong_viec">
                                                <?php if($data['yeu_cau_cong_viec'] != null): ?><?php echo $data['yeu_cau_cong_viec']; ?><?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <h4
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">
                                                <u>Quyền
                                                    lợi được hưởng</u></h4>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12"
                                                 id="quyen_loi_cong_viec">
                                                <?php if($data['quyen_loi'] != null): ?><?php echo $data['quyen_loi']; ?><?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">Địa
                                                chỉ</label>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12" id="dia_chi">
                                                <span><?php if($data['dia_chi'] != null): ?><?php echo e($data['dia_chi']); ?><?php endif; ?></span> -
                                                <a href="<?php echo e(route('trangchu.index',['dia_diem_id'=>$data['get_dia_diem']['id']])); ?>"
                                                   class="text-primary"><?php if($data['get_dia_diem'] != null): ?>
                                                        (<?php echo e($data['get_dia_diem']['name']); ?>)<?php endif; ?></a>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">Tính
                                                chất công việc</label>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 chuc_vu" id="chuc_vu">
                                                
                                                <?php if($data['get_chuc_vu'] != null): ?>
                                                    <div
                                                        class="btn btn-white border waves-effect"><a class="text-dark"
                                                                                                     href="<?php echo e(route('trangchu.index',['chuc_vu'=>$data['get_chuc_vu']['id']])); ?>"><?php echo e($data['get_chuc_vu']['name']); ?></a>
                                                    </div><?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">Chức
                                                vụ</label>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 chuc_vu">
                                                
                                                <?php if($data['get_kieu_lam_viec'] != null): ?>
                                                    <div
                                                        class="btn btn-white border waves-effect"><a class="text-dark"
                                                                                                     href="<?php echo e(route('trangchu.index',['kieu_lam_viec'=>$data['get_kieu_lam_viec']['id']])); ?>"><?php echo e($data['get_kieu_lam_viec']['name']); ?></a>
                                                    </div><?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">Ngành
                                                nghề</label>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 nganh_nghe"
                                                 id="nganh_nghe">
                                                <?php if($data['get_nganh_nghe'] != null): ?>
                                                    <?php echo e(implode('', array_map(function($c) {
            echo '<a class="btn btn-white waves-effect border text-dark loc-nganh-nghe" href="'.route('trangchu.index',['nganh_nghe'=>$c['id']]).'" data-id="'.$c['id'].'">'.$c['name'].'</a> ';
                                                        }, $data['get_nganh_nghe']))); ?>

                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">Yêu
                                                cầu bằng cấp</label>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 yc_bang_cap"
                                                 id="yc_bang_cap">
                                                <?php if($data['get_bang_cap'] != null): ?>
                                                    <?php echo e($data['get_bang_cap']['name']); ?>

                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">Yêu
                                                cầu kinh nghiệm</label>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 kinh_nghiem"
                                                 id="kinh_nghiem">
                                                <?php if($data['get_kinh_nghiem'] != null): ?>
                                                    <?php echo e($data['get_kinh_nghiem']['name']); ?>

                                                <?php endif; ?>
                                            </div>
                                        </div>


                                        <?php if($data['yeu_cau_ho_so'] != null && unserialize($data['yeu_cau_ho_so']) != null): ?>
                                            <?php if(count(unserialize($data['yeu_cau_ho_so'])) != 0): ?>
                                        <div class="form-group row">
                                            <label
                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-form-label text-left">Hồ
                                                sơ yêu cầu:</label>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 kinh_nghiem"
                                                 id="ho_so_yeu_cau">


                                                    <?php $__currentLoopData = unserialize($data['yeu_cau_ho_so']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php switch($row):
                                                            case (1): ?>
                                                            <?php echo e('Tiếng Anh,'); ?>

                                                            <?php break; ?>
                                                            <?php case (2): ?>
                                                            <?php echo e('Tiếng Việt,'); ?>

                                                            <?php break; ?>
                                                            <?php case (3): ?>
                                                            <?php echo e('Tiếng Pháp,'); ?>

                                                            <?php break; ?>
                                                            <?php case (4): ?>
                                                            <?php echo e('Tiếng Trung,'); ?>

                                                            <?php break; ?>
                                                            <?php case (5): ?>
                                                            <?php echo e('Tiếng Nhật,'); ?>

                                                            <?php break; ?>
                                                            <?php case (6): ?>
                                                            <?php echo e('Tiếng Hàn Quốc,'); ?>

                                                            <?php break; ?>

                                                        <?php endswitch; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                
                                                
                                                
                                            </div>
                                        </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 border-left">
                        <div class="w-100 position-relative overflow-y-auto">
                            <div class="w-100" id="noi-dung-right-side" style="height: 50px">
                                <div class="row">
                                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <h4 class="tieu_de bg-light p-1 m-0 text-center">Việc làm gợi ý<a
                                                class="float-right"
                                                href="<?php echo e(route('trangchu.index',array('kieu_lam_viec'=>$data['kieu_lam_viec_id']))); ?>">[Xem
                                                thêm]</a></h4>

                                    </div>
                                </div>
                                <div class="row">
                                    <?php if($data['bai_tuyen_dung']->count() != 0): ?>
                                        
                                        <?php $__currentLoopData = $data['bai_tuyen_dung']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="col-sm-12 col-md-12 ribbon-box iteam-click"
                                               href="<?php echo e(route('baiviet.getThongTinBaiViet',[$row['id'],'chitiet'=>1])); ?>">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <img src="<?php echo e(URL::asset($row['getCongTy']->cong_ty_logo)); ?>"
                                                             class="border" style="width: calc(100%)">
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="row">
                                                            <h5 class="col-sm-12 col-md-12 mt-1 mb-1 overflow-hidden text-capitalize">
                                                                <?php echo e($row['tieu_de']); ?>

                                                            </h5>
                                                        </div>
                                                        <div class="row">
                                                            <small
                                                                class="col-sm-12 col-md-12 overflow-hidden text-dark text-uppercase">
                                                                <?php echo e($row['getCongTy']->cong_ty_name); ?>

                                                            </small>
                                                        </div>
                                                        <div class="row">
                                                            <small class="col-sm-12 col-md-12">
                                                                <span class="icofont icofont-money mr-1">
                                                                    <?php echo e($row['luong_from']); ?><?php echo e(' - '); ?><?php echo e($row['luong_to']); ?><?php echo e(' Triệu'); ?>

                                                                </span>
                                                                
                                                            </small>
                                                        </div>
                                                        <div class="row">
                                                            <small class="col-sm-12 col-md-12">
                                                                <span
                                                                    class="icofont icofont-location-pin mr-1"></span><?php echo e($row['getDiaDiem']->dia_diem); ?>

                                                            </small>
                                                        </div>
                                                        <div class="row">
                                                            <small class="col-sm-12 col-md-12">
                                                                <span
                                                                    class="fa fa-calendar-plus-o mr-1"></span><?php echo e(\Illuminate\Support\Carbon::parse($row['han_tuyen'])->format('d/m/Y')); ?>

                                                            </small>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php if(intval($row['isHot']) == 1): ?>
                                                    <div class="ribbon-two ribbon-two-danger floats-right"><span
                                                            class="right-custom"
                                                            style="top: 7px;left: -14px;">Hot</span>
                                                    </div>
                                                <?php endif; ?>
                                            </a>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <div class="row">
                                            <div class="col-sm-12 col-md-12 bg-primary text-white text-center">
                                                <?php echo e(__('Không tìm thấy việc làm')); ?>

                                            </div>
                                        </div>
                                    <?php endif; ?>

                                </div>
                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                
                                
                                

                                
                                

                                
                                
                                
                                
                                
                                
                                

                                
                                

                                
                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                

                                
                                
                                


                                
                                
                                
                                
                                


                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                
                                
                                

                                
                                

                                
                                

                                
                                
                                

                                
                                

                                
                                
                            </div>


                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    <?php if(intval(Session::get('loai_tai_khoan')) == 1): ?>

        <?php echo $__env->make('NopDon.NopDonModal.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('User.modal.capNhatProject', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('User.modal.capNhatExp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        let idBaiTuyenDung = '<?php echo e($data['id']); ?>';
        $(function () {
            // fullSizePage();
            let size_parent_of_right_side = $('#container-section').height();
            console.log(size_parent_of_right_side)
            $('#noi-dung-right-side').css('height', size_parent_of_right_side + 'px')
        })
    </script>
    <script src="<?php echo e(URL::asset('assets\libs\multiselect\jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\jquery-quicksearch\jquery.quicksearch.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\select2\select2.min.js')); ?>"></script>

    
    <script src="<?php echo e(URL::asset('assets\libs\bootstrap-datepicker\bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\bootstrap-touchspin\jquery.bootstrap-touchspin.min.js')); ?>"></script>


    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\date-picker-vi.js')); ?>"></script>
    <!-- Plugins js-->
    <script src="<?php echo e(URL::asset('assets\libs\twitter-bootstrap-wizard\jquery.bootstrap.wizard.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\cap-nhat-kinh-nghiem.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\cap-nhat-project.js')); ?>"></script>

    <!-- Init js-->
    <script src="<?php echo e(URL::asset('assets\js\pages\form-wizard.init.js')); ?>"></script>


    <script type="text/javascript">
        $(function () {
            // viec-lam-tuong-tu-render
            getViecLamTuongTu();
            $('#trang-chu-like-post').on('click', function () {
                let __this = $(this);
                let idPost = __this.data('id');
                // console.log(idPost)
                if (__this.hasClass('btn-outline-primary') == true) {
                    __this.removeClass('btn-outline-primary');
                    __this.addClass('btn-primary');
                    __this.addClass('like-animation');
                    __this.find('i').text(' Đã lưu');
                    let ajax = {
                        method: 'post',
                        url: '/bai-viet/like',
                        data: {
                            id: idPost,
                            thich: 1
                        }
                    };
                    sendAjaxNoFunc(ajax.method, ajax.url, ajax.data, '')
                        .done(e => {
                            console.log(e)
                            __this.find('span').text(e.total_thich);

                            // $('.tong-luot-thich').text(e.total_thich);
                        });
                } else if (__this.hasClass('btn-primary') == true) {
                    __this.removeClass('btn-primary');
                    __this.removeClass('like-animation');
                    __this.addClass('btn-outline-primary');
                    __this.find('i').text(' Lưu bài');
                    let ajax = {
                        method: 'post',
                        url: '/bai-viet/like',
                        data: {
                            id: idPost,
                            thich: 0
                        }
                    };
                    sendAjaxNoFunc(ajax.method, ajax.url, ajax.data, '')
                        .done(e => {
                            // console.log(e)

                            __this.find('span').text(e.total_thich);
                        });

                }

            });

            $('#quan-tam-nha-tuyen-dung').on('click', function () {
                let __this = $(this);
                let idNhaTuyenDung = __this.data('id');
                // console.log(idNhaTuyenDung)
                // return;
                if (__this.hasClass('btn-outline-info') == true) {
                    __this.removeClass('btn-outline-info');
                    __this.addClass('btn-info');
                    __this.addClass('like-animation');
                    __this.find('i').text('Đã quan tâm');
                    let ajax = {
                        method: 'post',
                        url: '/quan-tam-nha-tuyen-dung',
                        data: {
                            id: idNhaTuyenDung,
                            quan_tam: 1
                        }
                    };
                    sendAjaxNoFunc(ajax.method, ajax.url, ajax.data, '')
                        .done(e => {
                            console.log(e)
                            __this.find('span').text(e.total_quan_tam);

                            // $('.tong-luot-thich').text(e.total_thich);
                        });
                } else if (__this.hasClass('btn-info') == true) {
                    __this.removeClass('btn-info');
                    __this.removeClass('like-animation');
                    __this.addClass('btn-outline-info');
                    __this.find('i').text('Quan tâm');
                    let ajax = {
                        method: 'post',
                        url: '/quan-tam-nha-tuyen-dung',
                        data: {
                            id: idNhaTuyenDung,
                            quan_tam: 0
                        }
                    };
                    sendAjaxNoFunc(ajax.method, ajax.url, ajax.data, '')
                        .done(e => {
                            // console.log(e)

                            __this.find('span').text(e.total_quan_tam);
                        });

                }

            });

        });

        let getViecLamTuongTu = () => {
            
            
            
            
            
            
            
            
        }
    </script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets\libs\sweetalert2\sweetalert2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\chuc-nang-bao-cao.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\chuc-nang-nop-don-ung-tuyen.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/BaiViet/chiTiet.blade.php ENDPATH**/ ?>