<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card mt-sm-2 mt-md-4">
                <div class="card-header bg-primary text-white"><?php echo e(__('Đăng ký tài khoản')); ?></div>

                <div class="card-body">
                    <?php echo $__env->make('Admin.Login.contentRegister', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/Admin/Login/register.blade.php ENDPATH**/ ?>