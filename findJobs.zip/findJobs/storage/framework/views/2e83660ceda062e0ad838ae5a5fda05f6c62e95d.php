<input type="hidden" id="action-phan-quyen" value="<?php echo e($data['id']); ?>">
<?php if($data['phan_quyen'] != null): ?>
<?php $__currentLoopData = $data['phan_quyen']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <label class="col-sm-12 col-md-12">
        <input type="radio" data-plugin="switchery" name="check_phan_quyen" data-color="#8D2226" <?php if(in_array($row['id'],$data['tai_khoan_phan_quyen']) == true): ?> checked <?php endif; ?> data-action="<?php echo e($row['id']); ?>"
               data-size="small">

        <span class="text-left border-left pl-1"><button class="btn btn-sm btn-danger p-0 pl-1 pr-1 xoa-mot-ta-vu d-none" data-action="<?php echo e($row['id']); ?>">-</button> <span><?php echo e($row['name']); ?></span></span>

    </label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/Admin/QuanLyTaiKhoan/viewPhanQuyen.blade.php ENDPATH**/ ?>