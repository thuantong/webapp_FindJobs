<?php $__env->startSection('content'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>

    </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/TrangChu/chiTiet.blade.php ENDPATH**/ ?>