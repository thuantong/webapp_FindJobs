<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo e(config('app.name')); ?></title>

    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
    <meta content="Coderthemes" name="author">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('assets\images\animat-diamond-color.gif')); ?>">

    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('assets\libs\jquery-vectormap\jquery-jvectormap-1.2.2.css')); ?>" rel="stylesheet"
          type="text/css">

    <!-- App css -->
    <link href="<?php echo e(URL::asset('assets\css\bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    
<!-- typicon icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\typicons-icons\css\typicons.min.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\themify-icons\themify-icons.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\font-awesome\css\font-awesome.min.css')); ?>">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\icofont\css\icofont.css')); ?>">
    <!-- feather Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\feather\css\feather.css')); ?>">
    <link href="<?php echo e(URL::asset('assets\css\croppie\croppie.css')); ?>" rel="stylesheet" type="text/css">
    
    <link href="<?php echo e(URL::asset('assets\css\croppie\demo.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Jquery Toast css -->
    
    <link href="<?php echo e(URL::asset('assets\js\vtoast\vtoast.css')); ?>" rel="stylesheet" type="text/css">
    
    <link href="<?php echo e(URL::asset('assets\css\app.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(URL::asset('assets\css\style-customs.css')); ?>" rel="stylesheet" type="text/css">

</head>



<body>

<!-- Pre-loader -->




<div id="preloader">
    <div class="progress mb-0" style="border-radius: 0px!important;">
        <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary" id="loadPage" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
    </div>










</div>
<!-- End Preloader-->

<!-- Begin page -->
<div id="wrapper">

    <!-- Topbar Start -->
    <div class="navbar-custom">

        <ul class="list-unstyled topnav-menu float-right mb-0">
            <li>

                <a href="/" class="nav-link text-white">
                    Việc làm
                </a>
            </li>
            <li class="d-none d-md-block">
                <a class="nav-link center-element search-field-new-query" id="search-field-new-query"  data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    <span class="text-white">Tìm kiếm</span>
                </a>
            </li>

            <?php if(Auth::user() != null): ?>


                <?php if(Session::exists('loai_tai_khoan') && Session::get('loai_tai_khoan') == 2): ?>





                <?php endif; ?>








            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle d-none waves-effect waves-light text-white" data-toggle="dropdown" href="#"
                   role="button" aria-haspopup="false" aria-expanded="false" id="goi-danh-sach-thong-bao">
                    <i class="icofont icofont-bell-alt noti-icon"></i>
                    <span class="badge badge-danger rounded-circle noti-icon-badge">0</span>
                </a>
                <div class="dropdown-menu dropdown-menu-right dropdown-lg">

                    <!-- item-->
                    <div class="dropdown-item noti-title">
                        <h5 class="m-0">
                                    <span class="float-right">



                                    </span>Thông báo
                        </h5>
                    </div>

                    <div class="slimscroll noti-scroll" id="danh-sach-thong-bao">

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item active">
                            <div class="notify-icon bg-soft-primary text-primary">
                                <i class="mdi mdi-comment-account-outline"></i>
                            </div>
                            <p class="notify-details">Doug Dukes commented on Admin Dashboard
                                <small class="text-muted">1 min ago</small>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon">
                                <img src="assets\images\users\avatar-2.jpg" class="img-fluid rounded-circle" alt="">
                            </div>
                            <p class="notify-details">Mario Drummond</p>
                            <p class="text-muted mb-0 user-msg">
                                <small>Hi, How are you? What about our next meeting</small>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon">
                                <img src="assets\images\users\avatar-4.jpg" class="img-fluid rounded-circle" alt="">
                            </div>
                            <p class="notify-details">Karen Robinson</p>
                            <p class="text-muted mb-0 user-msg">
                                <small>Wow ! this admin looks good and awesome design</small>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon bg-soft-warning text-warning">
                                <i class="mdi mdi-account-plus"></i>
                            </div>
                            <p class="notify-details">New user registered.
                                <small class="text-muted">5 hours ago</small>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon bg-info">
                                <i class="mdi mdi-comment-account-outline"></i>
                            </div>
                            <p class="notify-details">Caleb Flakelar commented on Admin
                                <small class="text-muted">4 days ago</small>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon bg-secondary">
                                <i class="mdi mdi-heart"></i>
                            </div>
                            <p class="notify-details">Carlos Crouch liked
                                <b>Admin</b>
                                <small class="text-muted">13 days ago</small>
                            </p>
                        </a>
                    </div>

                    <!-- All-->





                </div>
            </li>

            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light text-white" data-toggle="dropdown"
                   href="#" role="button" aria-haspopup="false" aria-expanded="false">
                    <img
                        src="<?php if(Auth::user()->avatar != null): ?><?php echo e(URL::asset(Auth::user()->avatar)); ?><?php elseif(Auth::user()->avatar == null): ?><?php echo e(URL::asset('images\default-user-icon-8.jpg')); ?><?php endif; ?>"
                        alt="user-image" class="rounded-circle">
                    <span class="pro-user-name ml-1">
                                <?php if(Auth::user() != null): ?><?php echo e(ucwords(Auth::user()->ho_ten)); ?><?php endif; ?> <i class="icofont icofont-caret-down"></i>
                            </span>
                </a>

                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                    <!-- item-->
                    <div class="dropdown-header noti-title">
                        <h6 class="text-overflow text-center m-0"><?php if(Auth::user() != null): ?><?php echo e(ucwords(Auth::user()->ho_ten)); ?><?php endif; ?></h6>
                    </div>

                    <!-- item-->
                    <a href="<?php if(Session::get('loai_tai_khoan') == 1): ?><?php echo e(route('user.nguoiTimViec')); ?><?php elseif(Session::get('loai_tai_khoan') == 2): ?><?php echo e(route('user.nhaTuyenDung')); ?><?php endif; ?>"
                       class="dropdown-item notify-item">
                        <i class="remixicon-account-circle-line"></i>
                        <span>Thông tin tài khoản</span>
                    </a>

                    <!-- item-->

















                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item  notify-item"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <i class="remixicon-logout-box-line"></i>
                        <span>Đăng xuất</span>
                        
                    </a>

                    <form id="logout-form" action="<?php echo e(route('auth.logout')); ?>" method="get" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                    <!-- item-->
                    
                    
                    
                    

                </div>
            </li>
            <?php else: ?>

                <?php if(\Illuminate\Support\Facades\Request::exists('admin')): ?>
                <li>
                    <a href="<?php echo e(URL::asset('/dang-nhap?admin')); ?>" class="nav-link text-white">
                        Đăng nhập
                    </a>
                </li>
                    <?php else: ?>
                    <li class="d-md-block d-none">
                        <a href="<?php echo e(URL::asset('/xem-chuc-nang-nha-tuyen-dung')); ?>" class="nav-link text-white">
                            Dành cho nhà tuyển dụng
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(URL::asset('/dang-nhap')); ?>" class="nav-link text-white">
                            Đăng nhập
                        </a>
                    </li>
                    <?php endif; ?>
            <?php endif; ?>

        </ul>


        <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
            <li>
                <a href="/" class="nav-link logo text-center">
                        <span class="logo">
                            <span class="logo-lg-text-light text-white"><?php echo e(env('APP_NAME')); ?></span>


                        <!-- <span class="logo-lg-text-light">Xeria</span> -->
                        </span>



                </a>
            </li>
            <li>
                <button class="button-menu-mobile waves-effect waves-light">
                    <i class="icofont icofont-navigation-menu"></i>
                </button>
            </li>


            <li class="dropdown dropdown-mega d-block">















































































































            </li>
        </ul>

    </div>
    <!-- end Topbar -->

    <!-- ========== Left Sidebar Start ========== -->
<?php echo $__env->make('master.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Left Sidebar End -->

    <!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->

    <div class="content-page">
        <div class="content">

            <!-- Start Content-->
            <div class="container-fluid">

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
                <div class="collapse position-fixed bg-primary" id="collapseExample" style="z-index: 2;width: calc(70%)">
                    <div class="card-box m-1 p-1 bg-primary border-primary" style="border-radius: 0px">
                        
                        <div class="row">
                            <div class="col-sm-12 col-md-12 ">
                                <form class="row" method="get" action="/" id="tim-kiem-bai-tuyen-dung-master">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-sm-12 col-md-4 center-element">
                                        <div class="input-group">
                                            <input type="search" class="form-control value-search" id="value-master-search" name="tieu_de"
                                                   placeholder="Nhập từ khóa..." value="<?php if(Request::exists('tieu_de') && Request::get('tieu_de') != ""): ?><?php echo e(Request::get('tieu_de')); ?><?php endif; ?>">
                                        </div>

                                    </div>
                                    <div class="col-sm-12 col-md-3 center-element">
                                        <select class="form-control" id="dia-diem-master-search" name="dia_diem">
                                            <option selected value="">Tất cả địa điểm</option>
                                            <?php $__currentLoopData = $dia_diem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($row['id']); ?>" <?php if(Request::exists('dia_diem') && Request::get('dia_diem') != "" && Request::get('dia_diem') == $row['id']): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($row['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-12 col-md-3 center-element">
                                        <select class="form-control" id="nganh-nghe-master-search" name="nganh_nghe">
                                            <option selected value="">Tất cả ngành nghề</option>
                                            <?php $__currentLoopData = $nganh_nghe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($row['id']); ?>" <?php if(Request::exists('nganh_nghe') && Request::get('nganh_nghe') != "" && Request::get('nganh_nghe') == $row['id']): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($row['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-2 col-md-2  center-element">

                                        <button type="button" class="btn btn-white waves-effect waves-light text-left" id="button-master-search"><i class="fa fa-search"></i></button>
                                        <a class="nav-link center-element fillter" id="fillter-new-query"  data-toggle="collapse" data-target="#collapseExample2" aria-expanded="false" aria-controls="collapseExample">
                                            <span class="text-white"><i class="fa fa-filter"></i></span>
                                        </a>
                                    </div>
                                    <div class="collapse bg-primary" id="collapseExample2" style="z-index: 2;width: calc(70%)">
                                        <div class="card-box m-1 p-1 bg-primary border-primary" style="border-radius: 0px">
                                            <div class="row">
                                                <div class="col-sm-6 col-md-6 ">
                                                    <div class="row pl-1 pr-1">
                                                        <label class="col-sm-12 col-md-12">Mức lương</label>
                                                        <select class="form-control col-sm-12 col-md-12" name="muc_luong">
                                                            <option selected value="">Tất cả mức lương</option>
                                                            <option value="1" <?php if(Request::exists('muc_luong') && Request::get('muc_luong') != "" && Request::get('muc_luong') == 1): ?><?php echo e('selected'); ?><?php endif; ?>>Từ 2 triệu</option>
                                                            <option value="2" <?php if(Request::exists('muc_luong') && Request::get('muc_luong') != "" && Request::get('muc_luong') == 2): ?><?php echo e('selected'); ?><?php endif; ?>>Từ 5 triệu</option>
                                                            <option value="3" <?php if(Request::exists('muc_luong') && Request::get('muc_luong') != "" && Request::get('muc_luong') == 3): ?><?php echo e('selected'); ?><?php endif; ?>>Từ 10 triệu</option>
                                                            <option value="4" <?php if(Request::exists('muc_luong') && Request::get('muc_luong') != "" && Request::get('muc_luong') == 4): ?><?php echo e('selected'); ?><?php endif; ?>>Từ 20 triệu</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-6 ">
                                                    <div class="row pl-1 pr-1">
                                                        <label class="col-sm-12 col-md-12">Chức vụ</label>
                                                        <select class="form-control col-sm-12 col-md-12" name="chuc_vu">
                                                            <option selected value="">Tất cả mức lương</option>
                                                            <?php $__currentLoopData = $chuc_vu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($row['id']); ?>"><?php echo e($row['name']); ?></option>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>


                        
                    </div>

                </div>
            <!-- end page title -->
            <?php echo $__env->yieldContent('content'); ?>

            <!-- end row -->
                <?php echo $__env->make('Chat.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div> <!-- container -->

        </div> <!-- content -->

        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12 col-md-12 mb-4">
                        <div class="row">
                            <div class="col-sm-12 col-md-3">
                                <div class="row">
                                    <div class="col-sm-12 col-md-12"><b class="text-white">Việc làm theo địa điểm</b></div>
                                    <?php for($i=0; $i<4;$i++): ?>
                                    <a class="col-sm-12 col-md-12 text-white waves-effect waves-light" href="<?php echo e(URL::asset('/?dia_diem='.$dia_diem[$i]['id'])); ?>"><?php echo e($dia_diem[$i]['name']); ?></a>
                                        <?php endfor; ?>
                                    <a class="col-sm-12 col-md-12 text-white waves-effect waves-light" href="<?php echo e(URL::asset('/danh-sach-viec-lam?type=1')); ?>" style="text-decoration: underline">Xem tất cả<span class="pl-1 fa fa-angle-double-right"></span></a>

                                </div>
                            </div>
                            <div class="col-sm-12 col-md-3">
                                <div class="row">
                                    <div class="col-sm-12 col-md-12"><b class="text-white">Việc làm theo ngành nghề</b></div>
                                    <?php for($i=0; $i<4;$i++): ?>
                                        <a class="col-sm-12 col-md-12 text-white waves-effect waves-light" href="<?php echo e(URL::asset('/?nganh_nghe='.$nganh_nghe[$i]['id'])); ?>"><?php echo e($nganh_nghe[$i]['name']); ?></a>
                                    <?php endfor; ?>
                                    <a class="col-sm-12 col-md-12 text-white waves-effect waves-light" href="<?php echo e(URL::asset('/danh-sach-viec-lam?type=2')); ?>" style="text-decoration: underline">Xem tất cả<span class="pl-1 fa fa-angle-double-right"></span></a>

                                </div>
                            </div>
                            <div class="col-sm-12 col-md-3">
                                <div class="row">
                                    <div class="col-sm-12 col-md-12"><b class="text-white">Việc làm theo kiểu làm việc</b></div>
                                    <?php for($i=0; $i<4;$i++): ?>
                                        <a class="col-sm-12 col-md-12 text-white waves-effect waves-light" href="<?php echo e(URL::asset('/?kieu_lam_viec='.$kieu_lam_viec[$i]['id'])); ?>"><?php echo e($kieu_lam_viec[$i]['name']); ?></a>
                                    <?php endfor; ?>
                                    <a class="col-sm-12 col-md-12 text-white waves-effect waves-light" href="<?php echo e(URL::asset('/danh-sach-viec-lam?type=3')); ?>" style="text-decoration: underline">Xem tất cả<span class="pl-1 fa fa-angle-double-right"></span></a>

                                </div>
                            </div>
                            <div class="col-sm-12 col-md-3">
                                <div class="row">
                                    <div class="col-sm-12 col-md-12"><b class="text-white">Việc làm theo chức vụ</b></div>
                                    <?php for($i=0; $i<4;$i++): ?>
                                        <a class="col-sm-12 col-md-12 text-white waves-effect waves-light" href="<?php echo e(URL::asset('/?chuc_vu='.$chuc_vu[$i]['id'])); ?>"><?php echo e($chuc_vu[$i]['name']); ?></a>
                                    <?php endfor; ?>
                                    <a class="col-sm-12 col-md-12 text-white waves-effect waves-light" href="<?php echo e(URL::asset('/danh-sach-viec-lam?type=4')); ?>" style="text-decoration: underline">Xem tất cả<span class="pl-1 fa fa-angle-double-right"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row bg-active">
                    <div class="col-sm-12 col-md-6">

                        <p class="pt-2"><b class="text-white">Website đăng tin tuyển dụng và tìm việc làm</b></p>
                        <p><b class="text-white">Tên: Tống Minh Thuận @email: tongminhthuan0405@gmail.com</b></p>



                    </div>
                    <div class="col-sm-12 col-md-6 center-element">
                        <div class="text-md-right footer-links d-none d-sm-block">
                            <a href="<?php echo e(route('trangchu.gioiThieuVeChungToi')); ?>" class="text-white waves-effect waves-light">Thông tin</a>

                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

    </div>

    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->


</div>


<!-- END wrapper -->









































<!-- /Right-bar -->

<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>

<script src="<?php echo e(URL::asset('assets\js\vendor.min.js')); ?>"></script>


<script src="<?php echo e(URL::asset('assets\libs\apexcharts\apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets\libs\jquery-sparkline\jquery.sparkline.min.js')); ?>"></script>



<!-- Peity chart-->
<script src="<?php echo e(URL::asset('assets\libs\peity\jquery.peity.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets\js\chat-js-customs.js')); ?>"></script>

<!-- Tost-->
<script src="<?php echo e(URL::asset('assets\js\vtoast\vtoast.js')); ?>"></script>


<!-- toastr init js-->

<!-- init js -->

<!-- Modal-Effect -->
<script src="<?php echo e(URL::asset('assets\libs\custombox\custombox.min.js')); ?>"></script>

<script src="<?php echo e(URL::asset('assets\js\croppie\croppie.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(URL::asset('assets\js\app.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets\js\customs-js-mine.js')); ?>"></script>



<?php echo $__env->yieldPushContent('scripts'); ?>
<!-- Vendor js -->

<script src="<?php echo e(URL::asset('assets\js\app\lay-danh-sach-viec-lam.js')); ?>"></script>
<script type="text/javascript">

    // $(window).on('load',function () {
        // $('body').removeClass('loadPage')
        // $('#loadPage').parent().fadeOut('slow')
        // $("#loadPage").removeClass("done");
        // $({property: 0}).animate({property: 105}, {
        //     duration: 4000,
        //     step: function() {
        //         var _percent = Math.round(this.property);
        //
        //
        //         if(_percent == 105) {
        //             $('#loadPage').hide(); //make it invisible
        //             $('#loadPage').css('width', "0%"); //Reset to 0
        //         }else{
        //             $('#loadPage').show(); //show it.
        //             $('#loadPage').css('width',  _percent+"%"); //progress
        //         }
        //     },
        //     complete: function() {
        //         $("#loadPage").parent().fadeOut('slow');
        //     }
        // });
    // })
    // var currenPage = null;
    // var nextPage = null;
    // var next_page_check = null;
    $(document).on('click', '#button-master-search', function () {
        $('#tim-kiem-bai-tuyen-dung-master').submit()
        // let tieu_de = $('#value-master-search').val();
        // let nganh_nghe = $('#nganh-nghe-master-search').val();
        // let dia_diem = $('#dia-diem-master-search').val();
        // if (nganh_nghe == -1) {
        //     nganh_nghe = '';
        // }
        // if (dia_diem == -1) {
        //     dia_diem = '';
        // }
        // let ajax = {
        //     method: 'get',
        //     url: '/tin-tuyen-dung',
        //     // url: '/bai-viet/tim-kiem', chưa xóa route
        //     data: {
        //         tieu_de: tieu_de,
        //         nganh_nghe_id: nganh_nghe,
        //         dia_diem_id: dia_diem,
        //     }
        // }
        // getItemsDefaults($('#left-search-content'), 1, ajax, 'timkiem')
    });

    // $(document).on('click', function (e) {
    //
    //     if (!$(e.target).hasClass('left-search') && $(e.target).parents('.left-search').length == 0) {
    //         $('.exit-search').trigger('click');
    //     }
    //     if ($(e.target).hasClass('search-field') || $(e.target).parents('.search-field').length > 0) {
    //         $('.left-search').removeClass('d-none').fadeIn('slow');
    //         if ($(document).width()) {
    //             $('.left-search').css('width', $(document).width() + 'px');
    //             if ($(document).width() < 500) {
    //                 $('.left-search').css('width', $(document).width() + 'px');
    //             } else if ($(document).width() > 500) {
    //                 $('.left-search').css('width', ($(document).width() * 0.8) + 'px');
    //             }
    //         }
    //         $('.value-search').focus();
    //     }
    // });
    $(function () {

        fullSizePage();
        $('#loadPage').css('width','80%');
        $(window).on('load',function () {
            $('#loadPage').parent().fadeOut('slow')
        });
        select2Default($('#dia-diem-master-search'));
        select2Default($('#nganh-nghe-master-search'));
        // select2Default($('#dia-diem-master-search')).select2({
        //     dropdownParent : $('.left-search-header')
        // }
        // );
        // select2Default($('#nganh-nghe-master-search'));
        // select2Single($('#dia-diem-master-search',$('.left-search-header')));
        // select2Single($('#nganh-nghe-master-search',$('.left-search-header')));
        // $('.left-search').css('width', '0px');
        // $('.left-search-content').css('max-height', ($(document).height() * 0.8) + 'px');
        // $('.left-search-header').css('min-height', $('.navbar-custom').height() + 'px');

        // $('#nganh-nghe-master-search').on('select2:close',function () {
        //     // alert()
        //     $('.select2-container-active').removeClass('select2-container-active');
        //     // $(':focus').blur();
        //     $('#value-master-search').focus();
        // });
//exit search container
//         $('.exit-search').on('click', function () {
//             $('.left-search').addClass('d-none').fadeOut().css('width', '0px');
//             $('.value-search').val('');
        //
        // });

        // $(window).resize(function () {
        //     if ($(document).width()) {
        //         $('.left-search').css('width', $(document).width() + 'px');
        //         if ($(document).width() < 769) {
        //             $('.left-search').css('width', $(document).width() + 'px');
        //         } else if ($(document).width() > 768) {
        //             $('.left-search').css('width', ($(document).width() * 0.8) + 'px');
        //         }
        //     }
        // });

    });
    // $(document).on('keyup',function (e) {
    //     if ($('.left-search').hasClass('d-none') == false){
    //         if (e.keyCode == 13){
    //             $('#button-master-search').trigger('click');
    //         }
    //         // console.log(e)
    //     }
    // });
</script>
</body>
</html>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/master/index.blade.php ENDPATH**/ ?>