<div class="modal fade bs-example-modal-center" id="xem_anh_dai_dien" tabindex="-1" role="dialog"
     aria-labelledby="myCenterModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            
            
            
            
            <div class="modal-body p-0">
                <button type="button" class="close position-absolute" style="right: 1rem" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
                <img src="" style="width: 100%">
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/CongTy/modal/xemAnhDaiDien.blade.php ENDPATH**/ ?>