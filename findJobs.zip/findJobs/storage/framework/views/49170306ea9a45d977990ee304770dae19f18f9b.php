<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary"><?php echo e(__('Thông tin xác thực Email')); ?></div>

                    <div class="card-body">
                        
                        
                        
                        
                        


                        <div class="form-group row">
                            <div class="col-sm-12 col-md-12">
                                <span
                                    class="<?php if($status == 200): ?> text-success <?php elseif($status == 400): ?> text-danger <?php endif; ?> message-response"><?php echo e($message); ?></span>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        let status = '<?php echo e($status); ?>';
        let loai = '<?php echo e(Session::get('loai_tai_khoan')); ?>';
        $(function () {
            // console.log(loai)
            switch (parseInt(status)) {
                case 200:
                    setTimeout(function () {
                        let redirectTo = null;
                        switch (parseInt(loai)) {
                            case 1:
                                redirectTo = '/';
                                break;
                            case 2:
                                redirectTo = '<?php echo e(route('user.nhaTuyenDung')); ?>';
                                break;
                            case 3:
                                redirectTo = '<?php echo e(route('admin.index')); ?>';
                                break
                        }
                        if (loai == null){
                            redirectTo = '/';
                        }
                        location.href = redirectTo;
                    }, 2000);
                    break;
                case 400:
                    break;
            }


        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/TaiKhoan/thongBaoXacThuc.blade.php ENDPATH**/ ?>