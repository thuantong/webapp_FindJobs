<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary"><?php echo e(__('Xác thực thông tin Email của bạn')); ?></div>

                <div class="card-body">






                    <?php echo e(__('Để sử dụng dịch vụ của ứng đụng trang,')); ?>

                    <?php echo e(__('Bạn cần xác thực lại thông tin email! Và sau đó, kiểm tra lại hộp thư của emai: ')); ?>

                    <div class="form-group row">
                        <div class="col-sm-12 col-md-12">
                            <div class="input-group">
                                <input class="form-control email-not-null" id="email" value="<?php echo e(Auth::user()->email); ?>">
                                <button class="btn btn-primary" id="gui-xac-nhan-email">Gửi xác thực email</button>
                                <span class="invalid-feedback" role="alert">
                                        <strong></strong>
                                    </span>
                            </div>
                            <span class="text-success message-response"></span>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    
    <script type="text/javascript">
        let data_action_confifm = '<?php echo e(Auth::user()->id); ?>';
    </script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets/js/app/chuc-nang-gui-confirm-email.js')); ?>"></script>
























    <?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/auth/verify.blade.php ENDPATH**/ ?>