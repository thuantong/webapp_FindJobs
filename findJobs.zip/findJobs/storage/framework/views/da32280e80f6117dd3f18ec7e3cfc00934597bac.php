<?php if($typeSend == 0): ?>
    <li class="timeline-sm-item">
        <span class="timeline-sm-date time-exp"><b><?php echo e($data['exp_from']); ?></b><br>đến<br><b><?php echo e($data['exp_to']); ?></b></span>
        <div class="btn-group btn-group-sm mb-1" style="float: none;">

            <button class="btn btn-sm btn-warning mr-1 cap-nhat-exp"><?php echo e(__('Cập nhật')); ?></button>
            <button class="btn btn-sm btn-danger ml-1 mr-1 xoa1-exp"><?php echo e(__('Xóa')); ?></button>
        </div>

        <h5 class="mt-0 mb-1 company-name-exp" style="text-transform: capitalize"><?php echo e($data['cong_ty_chuc_vu']); ?></h5>

        <p class="company-link-exp"><?php echo e($data['trang_web']); ?></p>
        <p class="text-muted mt-2 description-exp"><?php echo e($data['mo_ta']); ?></p>
    </li>
<?php elseif($typeSend == 1): ?>
    <?php if($data['nguoi_tim_viec']['exp_lam_viec'] != null): ?>

        <?php $__currentLoopData = $data['nguoi_tim_viec']['exp_lam_viec']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="timeline-sm-item">
                <span class="timeline-sm-date time-exp"><b><?php echo e($row['from_date']); ?></b><br>đến<br><b><?php echo e($row['to_date']); ?></b></span>
                <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                <?php else: ?>
                    <div class="btn-group btn-group-sm mb-1" style="float: none;">
                        <button class="btn btn-sm btn-warning mr-1 cap-nhat-exp"><?php echo e(__('Cập nhật')); ?></button>
                        <button class="btn btn-sm btn-danger ml-1 mr-1 xoa1-exp"><?php echo e(__('Xóa')); ?></button>
                    </div>
                <?php endif; ?>

                <h5 class="mt-0 mb-1 company-name-exp"style="text-transform: capitalize"><?php echo e($row['tenCtyVaChucVu']); ?></h5>

                <p class="company-link-exp"><?php echo e($row['websites']); ?></p>
                <p class="text-muted mt-2 description-exp"><?php echo e($row['mo_ta']); ?></p>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/User/nguoiTimViec/htmlKinhNghiemLamViec.blade.php ENDPATH**/ ?>