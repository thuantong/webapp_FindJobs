<div class="left-side-menu left-side-menu-custom pt-0">


























    <div class="slimscroll-menu">
    

    <!--- Sidemenu -->
        <div id="sidebar-menu">
            
            
            <ul class="metismenu" id="side-menu">

                <?php if(Auth::user() != null): ?>
                    <li class="">
                        <?php if(Session::get('loai_tai_khoan') != 3 && Session::get('loai_tai_khoan') != 1): ?>
                            <?php if(Session::exists('so_du') == false): ?>
                                <a href="<?php echo e(route('sodu.index')); ?>" class="waves-effect text-center">
                                    <i class="fa fa-usd"></i>
                                    <span><?php echo e(__('Chưa đăng ký số dư')); ?></span>
                                </a>
                            <?php else: ?>
                                <div class="input-group center-element">
                                    <span class="text-center"><b><?php echo e(__('Số dư: ')); ?>&nbsp;</b></span>
                                    <a class="waves-effect" href="<?php echo e(route('sodu.index')); ?>"><?php echo number_format(Session::get('so_du'), 0); ?></a>
                                    
                                    <span class="text-center"><b>&nbsp;Xu</b></span>
                                </div>

                            <?php endif; ?>
                    </li>
                <?php endif; ?>

                <?php if(Session::get('loai_tai_khoan') == 1): ?>
                    <li>
                        <a href="<?php echo e(route('nguoitimviec.index')); ?>" class="waves-effect">
                            <i class="fa fa-file-text-o"></i>
                            <span><?php echo e(__('Bài đã lưu')); ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('nopdon.danhSachBaiDaNopDon')); ?>" class="waves-effect">
                            <i class="fa fa-list-alt"></i>
                            <span><?php echo e(__('Kiểm tra ứng tuyển')); ?></span>
                        </a>
                    </li>

                <?php endif; ?>

                
                <?php if(Session::get('loai_tai_khoan') == 2): ?>
                    <li>
                        <a href="<?php echo e(route('baiviet.index')); ?>" class="waves-effect">
                            <i class="fa fa-file-text-o"></i>
                            <span><?php echo e(__('Đăng bài tuyển dụng')); ?></span>
                        </a>
                    </li>
                    <li class="menu-title"><?php echo e(__('Quản lý tuyển dụng')); ?></li>
                    <li>
                        <a href="<?php echo e(route('congty.index')); ?>" class="waves-effect">
                            <i class="fa fa-building"></i>
                            <span><?php echo e(__('Quản lý Công Ty')); ?></span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('quanlybaidang.index')); ?>" class="waves-effect">
                            <i class="fa fa-list-alt"></i>
                            <span><?php echo e(__('Quản lý bài đăng').'('.\App\Models\TaiKhoan::query()->find(\Illuminate\Support\Facades\Auth::user()->id)->getNhaTuyenDung->getBaiViet()->count().")"); ?></span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('quanlyungvien.index')); ?>" class="waves-effect">
                            <i class="fa fa-users"></i>
                            <span><?php echo e(__('Quản lý ứng viên')); ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('nhatuyendung.index')); ?>" class="waves-effect">
                            <i class="fa fa-users"></i>
                            <span><?php echo e(__('Tìm ứng viên')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>


















                <?php if(Session::get('loai_tai_khoan') == 2): ?>
                    <li class="menu-title"><?php echo e(__('Thông tin tuyển dụng')); ?></li>



                <?php endif; ?>
                <?php if(Session::exists('loai_tai_khoan') && Session::get('loai_tai_khoan') == 1): ?>
                    <li>
                        <a href="<?php echo e(route('nguoitimviec.timKiemNhaTuyenDung')); ?>" class="waves-effect">
                            <i class="fa fa-users"></i>
                            <span>Tìm kiếm nhà tuyển dụng</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Session::get('loai_tai_khoan') == 3): ?>
                    <li class="menu-title"><?php echo e(__('Quản trị viên')); ?></li>

                    <li>
                        <a href="<?php echo e(route('admin.duyetbaiviet')); ?>" class="waves-effect">
                            <i class="fa fa-check-square-o"></i>
                            <span><?php echo e(__('Duyệt bài viết')); ?></span>
                        </a>
                    </li>








                    <li>
                        <a href="javascript: void(0);" class="waves-effect">
                            <i class="fa fa-users"></i>
                            <span><?php echo e(__('Quản lý tài khoản')); ?></span>
                            <span class="menu-arrow" data-icon="&#9699;"></span>
                        </a>
                        <ul class="nav-second-level" aria-expanded="false">
                            <li>
                                <a href="<?php echo e(route('admin.danhSachTacVu')); ?>">Phân quyền bộ phận</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.danhSachTaiKhoan')); ?>">Phân quyền tài khoản</a>
                            </li>

                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo e(route('thecao.index')); ?>" class="waves-effect">
                            <i class="fa fa-credit-card"></i>
                            <span><?php echo e(__('Thẻ nạp')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php endif; ?>
            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/master/nav.blade.php ENDPATH**/ ?>