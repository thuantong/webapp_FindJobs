<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo e(config('app.name')); ?></title>

    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
    <meta content="Coderthemes" name="author">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('assets\images\animat-diamond-color.gif')); ?>">

    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('assets\libs\jquery-vectormap\jquery-jvectormap-1.2.2.css')); ?>" rel="stylesheet"
          type="text/css">

    <!-- App css -->
    <link href="<?php echo e(URL::asset('assets\css\bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    
<!-- typicon icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\typicons-icons\css\typicons.min.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\themify-icons\themify-icons.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\font-awesome\css\font-awesome.min.css')); ?>">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\icofont\css\icofont.css')); ?>">
    <!-- feather Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets\icon\feather\css\feather.css')); ?>">
    <link href="<?php echo e(URL::asset('assets\css\croppie\croppie.css')); ?>" rel="stylesheet" type="text/css">
    
    <link href="<?php echo e(URL::asset('assets\css\croppie\demo.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Jquery Toast css -->
    
    <link href="<?php echo e(URL::asset('assets\js\vtoast\vtoast.css')); ?>" rel="stylesheet" type="text/css">
    
    <link href="<?php echo e(URL::asset('assets\css\app.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(URL::asset('assets\css\style-customs.css')); ?>" rel="stylesheet" type="text/css">

</head>



<body>

<!-- Pre-loader -->
<div id="preloader">
    <div class="progress mb-0" style="border-radius: 0px!important;">
        <div class="progress-bar progress-bar-striped progress-bar-animated bg-success" id="loadPage" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
    </div>
</div>
<!-- End Preloader-->

<!-- Begin page -->
<div id="wrapper">

    <!-- Topbar Start -->
    <div class="navbar-custom">

        <ul class="list-unstyled topnav-menu float-right mb-0">
            <li>
                <a href="/" class="nav-link text-white">
                    Việc làm
                </a>
            </li>
            
            
            
            
            

            

            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle  waves-effect waves-light text-white" data-toggle="dropdown" href="#"
                   role="button" aria-haspopup="false" aria-expanded="false">
                    <i class="icofont icofont-bell-alt noti-icon"></i>
                    <span class="badge badge-danger rounded-circle noti-icon-badge" id="so-luong-thong-bao"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right dropdown-lg">

                    <!-- item-->
                    <div class="dropdown-item noti-title">
                        <h5 class="m-0">
                                    <span class="float-right">



                                    </span>Thông báo
                        </h5>
                    </div>

                    <div class="slimscroll noti-scroll" id="danh-sach-thong-bao" >


                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon">
                                <img src="assets\images\users\avatar-2.jpg" class="img-fluid rounded-circle" alt="">
                            </div>
                            <p class="notify-details">Mario Drummond</p>
                            <p class="text-muted mb-0 user-msg">
                                <small>Hi, How are you? What about our next meeting</small>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon">
                                <img src="assets\images\users\avatar-4.jpg" class="img-fluid rounded-circle" alt="">
                            </div>
                            <p class="notify-details">Karen Robinson</p>
                            <p class="text-muted mb-0 user-msg">
                                <small>Wow ! this admin looks good and awesome design</small>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon bg-soft-warning text-warning">
                                <i class="mdi mdi-account-plus"></i>
                            </div>
                            <p class="notify-details">New user registered.
                                <small class="text-muted">5 hours ago</small>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon bg-info">
                                <i class="mdi mdi-comment-account-outline"></i>
                            </div>
                            <p class="notify-details">Caleb Flakelar commented on Admin
                                <small class="text-muted">4 days ago</small>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <div class="notify-icon bg-secondary">
                                <i class="mdi mdi-heart"></i>
                            </div>
                            <p class="notify-details">Carlos Crouch liked
                                <b>Admin</b>
                                <small class="text-muted">13 days ago</small>
                            </p>
                        </a>
                    </div>

                    <!-- All-->





                </div>
            </li>

            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light text-white" data-toggle="dropdown"
                   href="#" role="button" aria-haspopup="false" aria-expanded="false">
                    <img
                        src="<?php if(Session::get('avatar') != null): ?><?php echo e(URL::asset(Session::get('avatar'))); ?><?php elseif(Session::get('avatar') == null): ?><?php echo e(URL::asset('images\default-user-icon-8.jpg')); ?><?php endif; ?>"
                        alt="user-image" class="rounded-circle">
                    <span class="pro-user-name ml-1">
<?php if(Auth::user() != null): ?><?php echo e(ucwords(Auth::user()->ho_ten)); ?><?php endif; ?> <i class="icofont icofont-caret-down"></i>
</span>
                </a>

                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                    <!-- item-->
                    <div class="dropdown-header noti-title">
                        <h6 class="text-overflow text-center m-0"><?php if(Auth::user() != null): ?><?php echo e(ucwords(Auth::user()->ho_ten)); ?><?php endif; ?></h6>
                    </div>

                    <!-- item-->
                    <a href="<?php if(Session::get('loai_tai_khoan') == 1): ?><?php echo e(route('user.nguoiTimViec')); ?><?php elseif(Session::get('loai_tai_khoan') == 2): ?><?php echo e(route('user.nhaTuyenDung')); ?><?php endif; ?>"
                       class="dropdown-item notify-item">
                        <i class="remixicon-account-circle-line"></i>
                        <span>Thông tin tài khoản</span>
                    </a>

                    <!-- item-->

















                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('auth.logout',['admin'=>true])); ?>" class="dropdown-item  notify-item">
                        <i class="remixicon-logout-box-line"></i>
                        <span>Đăng xuất</span>
                        
                    </a>











                    <!-- item-->
                    
                    
                    
                    

                </div>
            </li>


        </ul>


        <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
            <li>
                <a href="/" class="nav-link logo text-center">
<span class="logo-lg">
<img src="assets\images\logo-sm.png" alt="" height="24">

<!-- <span class="logo-lg-text-light">Xeria</span> -->
</span>
                    <span class="logo-sm">
<!-- <span class="logo-sm-text-dark">X</span> -->
<img src="assets\images\logo-sm.png" alt="" height="24">
</span>
                </a>
            </li>
            <li>
                <button class="button-menu-mobile waves-effect waves-light">
                    <i class="icofont icofont-navigation-menu"></i>
                </button>
            </li>


            <li class="dropdown dropdown-mega d-block">

                <a class="nav-link center-element search-field" data-search="search-field">
                    <span>Tìm kiếm</span>
                </a>
                <div class="dropdown-menu dropdown-megamenu">
                    <div class="row">
                        <div class="col-sm-6">

                            <div class="row">
                                <div class="col-md-4">
                                    <h5 class="text-dark mt-0">UI Components</h5>
                                    <ul class="list-unstyled megamenu-list">
                                        <li>
                                            <a href="javascript:void(0);">Widgets</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Nestable List</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Range Sliders</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Masonry Items</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Sweet Alerts</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Treeview Page</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Tour Page</a>
                                        </li>
                                    </ul>
                                </div>

                                <div class="col-md-4">
                                    <h5 class="text-dark mt-0">Applications</h5>
                                    <ul class="list-unstyled megamenu-list">
                                        <li>
                                            <a href="javascript:void(0);">eCommerce Pages</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">CRM Pages</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Email</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Calendar</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Team Contacts</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Task Board</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Email Templates</a>
                                        </li>
                                    </ul>
                                </div>

                                <div class="col-md-4">
                                    <h5 class="text-dark mt-0">Extra Pages</h5>
                                    <ul class="list-unstyled megamenu-list">
                                        <li>
                                            <a href="javascript:void(0);">Left Sidebar with User</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Menu Collapsed</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Small Left Sidebar</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">New Header Style</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Search Result</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Gallery Pages</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">Maintenance & Coming Soon</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="text-center mt-3">
                                <h3 class="text-dark">Special Discount Sale!</h3>
                                <h4>Save up to 70% off.</h4>
                                <button class="btn btn-primary mt-3">Download Now <i
                                        class="ml-1 mdi mdi-arrow-right"></i></button>
                            </div>
                        </div>
                    </div>

                </div>
            </li>
        </ul>
    </div>
    <!-- end Topbar -->

    <!-- ========== Left Sidebar Start ========== -->
<?php echo $__env->make('master.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Left Sidebar End -->

    <!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->

    <div class="content-page">
        <div class="content">

            <!-- Start Content-->
            <div class="container-fluid">

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <!-- end page title -->
            <?php echo $__env->yieldContent('content'); ?>

            <!-- end row -->
                <?php echo $__env->make('Chat.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div> <!-- container -->

        </div> <!-- content -->

        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        Tống Minh Thuận - 15020551
                    </div>
                    <div class="col-md-6">
                        <div class="text-md-right footer-links d-none d-sm-block">
                            <a href="javascript:void(0);">About Us</a>
                            <a href="javascript:void(0);">Help</a>
                            <a href="javascript:void(0);">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

    </div>

    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->


</div>


<!-- END wrapper -->
<div class="left-search d-none position-absolute bg-white border">
    <div class="left-search-header border" style="display: flex">
        <div class="col-sm-1 col-md-1 col-lg-1 col-xl-1 center-element">
            <button class="btn btn-white border text-left text-dark exit-search fa fa-times"></button>
        </div>
        <div class="col-sm-3 col-md-3 col-lg-3 col-xl-3 center-element">
            <div class="input-group">
                <input type="search" class="form-control value-search" id="value-master-search"
                       placeholder="Nhập từ khóa...">
            </div>

        </div>
        <div class="col-sm-3 col-md-3 col-lg-3 col-xl-3 center-element">
            <select class="form-control" id="dia-diem-master-search">
                <option selected value="-1">Chọn địa điểm</option>
                <?php $__currentLoopData = $dia_diem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row['id']); ?>"><?php echo e($row['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-3 col-md-3 col-lg-3 col-xl-3 center-element">
            <select class="form-control" id="nganh-nghe-master-search">
                <option selected value="-1">Tất cả</option>
                <?php $__currentLoopData = $nganh_nghe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row['id']); ?>"><?php echo e($row['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 center-element">
            <button class="btn btn-primary text-left" id="button-master-search"><i class="fa fa-search"></i></button>

        </div>
    </div>
    <div class="left-search-content overflow-y-auto p-2" id="left-search-content">
        
    </div>
</div>




<!-- /Right-bar -->

<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>

<!-- Vendor js -->
<script src="<?php echo e(URL::asset('assets\js\vendor.min.js')); ?>"></script>

<script src="<?php echo e(URL::asset('assets\libs\apexcharts\apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets\libs\jquery-sparkline\jquery.sparkline.min.js')); ?>"></script>



<!-- Peity chart-->
<script src="<?php echo e(URL::asset('assets\libs\peity\jquery.peity.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets\js\chat-js-customs.js')); ?>"></script>

<!-- Tost-->
<script src="<?php echo e(URL::asset('assets\js\vtoast\vtoast.js')); ?>"></script>


<!-- toastr init js-->

<!-- init js -->

<!-- Modal-Effect -->
<script src="<?php echo e(URL::asset('assets\libs\custombox\custombox.min.js')); ?>"></script>

<script src="<?php echo e(URL::asset('assets\js\croppie\croppie.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(URL::asset('assets\js\app.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets\js\customs-js-mine.js')); ?>"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
<script src="<?php echo e(URL::asset('assets\js\app\lay-danh-sach-viec-lam.js')); ?>"></script>
<script type="text/javascript">
    let getBaseURL = '<?php echo e(URL::asset('/')); ?>';
    let avatarDefault = '<?php echo e(URL::asset('images/default-company-logo.jpg')); ?>';
    // var currenPage = null;
    // var nextPage = null;
    const locationThongBao = () =>{
        let ajax = {
            method:'get',
            url:"/admin/thong-bao/cap-nhat-tin-rong",
            data:{}
        }
        sendAjaxNoFunc(ajax.method,ajax.url,ajax.data,'').done(e=>{
            if (e == true){
                location.href = "/admin/danh-sach-bai-duyet";
            }
        })

    }
    const htmlThongBao = (avatar,ho_ten,noi_dung)=>{
        let avatarNew = avatar == null ? avatarDefault : avatar;
        return ' <a onclick="locationThongBao()" class="dropdown-item notify-item">\n' +
            '                            <div class="notify-icon">\n' +
            '                                <img src="'+avatarNew+'" class="img-fluid rounded-circle" alt="">\n' +
            '                            </div>\n' +
            '                            <p class="notify-details">'+ho_ten+'</p>\n' +
            '                            <p class="text-muted mb-0 user-msg">\n' +
            '                                <small>'+noi_dung+'</small>\n' +
            '                            </p>\n' +
            '                        </a>';
    }
    const getDanhSachThongBao = ()=>{
        // so-luong-thong-b/**/ao
        // danh-sach-thong-bao
        let ajax = {
            method:'get',
            url:"/admin/get-thong-bao",
            data: {
            }
        }
        sendAjaxNoFunc(ajax.method,ajax.url,ajax.data,'').done(e=>{
            console.log(e);
            let count = 0;
            let html = '';
            $.each(e,function (i,v) {
                if (v.status == 0){
                    count++;
                }
                html += htmlThongBao(v.get_nguoi_gui.avatar,v.get_nguoi_gui.ho_ten,v.name);

            })

            $('#so-luong-thong-bao').html(count);
            $('#danh-sach-thong-bao').html(html);
        })
    }
    $(document).on('click', '#button-master-search', function () {
        let tieu_de = $('#value-master-search').val();
        let nganh_nghe = $('#nganh-nghe-master-search').val();
        let dia_diem = $('#dia-diem-master-search').val();
        if (nganh_nghe == -1) {
            nganh_nghe = '';
        }
        if (dia_diem == -1) {
            dia_diem = '';
        }
        let ajax = {
            method: 'get',
            url: '/tin-tuyen-dung',
// url: '/bai-viet/tim-kiem', chưa xóa route
            data: {
                tieu_de: tieu_de,
                nganh_nghe_id: nganh_nghe,
                dia_diem_id: dia_diem,
            }
        }
        getItemsDefaults($('#left-search-content'), 1, ajax, 'timkiem')
    });

    $(document).on('click', function (e) {

        if (!$(e.target).hasClass('left-search') && $(e.target).parents('.left-search').length == 0) {
            $('.exit-search').trigger('click');
        }
        if ($(e.target).hasClass('search-field') || $(e.target).parents('.search-field').length > 0) {
            $('.left-search').removeClass('d-none').fadeIn('slow');
            if ($(document).width()) {
                $('.left-search').css('width', $(document).width() + 'px');
                if ($(document).width() < 500) {
                    $('.left-search').css('width', $(document).width() + 'px');
                } else if ($(document).width() > 500) {
                    $('.left-search').css('width', ($(document).width() * 0.8) + 'px');
                }
            }
            $('.value-search').focus();
        }
    });
    $(function () {
        getDanhSachThongBao()
        select2Single($('#dia-diem-master-search'), $('.left-search-header'));
        select2Single($('#nganh-nghe-master-search'), $('.left-search-header'));
        $('.left-search').css('width', '0px');
        $('.left-search-content').css('max-height', ($(document).height() * 0.8) + 'px');
        $('.left-search-header').css('min-height', $('.navbar-custom').height() + 'px');

//exit search container
        $('.exit-search').on('click', function () {
            $('.left-search').addClass('d-none').fadeOut().css('width', '0px');
            $('.value-search').val('');

        });

        $(window).resize(function () {
            if ($(document).width()) {
                $('.left-search').css('width', $(document).width() + 'px');
                if ($(document).width() < 769) {
                    $('.left-search').css('width', $(document).width() + 'px');
                } else if ($(document).width() > 768) {
                    $('.left-search').css('width', ($(document).width() * 0.8) + 'px');
                }
            }
        });


    });
</script>
</body>
</html>








































































































































































































































































































































































































































































<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/Admin/index.blade.php ENDPATH**/ ?>