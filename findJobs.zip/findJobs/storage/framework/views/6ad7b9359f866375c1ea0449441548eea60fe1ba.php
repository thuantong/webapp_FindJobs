<?php $__env->startSection('content'); ?>
    trang chu
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/Admin/TrangChu/index.blade.php ENDPATH**/ ?>