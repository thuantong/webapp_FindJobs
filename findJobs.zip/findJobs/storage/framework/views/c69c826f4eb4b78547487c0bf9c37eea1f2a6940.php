
    <button class="btn btn-success save-bai-tuyen-dung" id="save">Đăng bài</button>
    <button class="btn btn-info d-none review" id="review">Xem trước</button>


<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/BaiViet/buttonDangBai.blade.php ENDPATH**/ ?>