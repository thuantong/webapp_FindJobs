<input type="hidden" id="hidden-no-action" value="<?php echo e($data['id']); ?>">
<?php $__currentLoopData = $data['tac_vu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <label class="col-sm-6 col-md-6">
        <input type="checkbox" data-plugin="switchery" data-color="#8D2226" <?php if(in_array($row['id'],$data['da_phan_quyen']) == true): ?> checked <?php endif; ?> data-action="<?php echo e($row['id']); ?>"
               data-size="small">

        <span class="text-left border-left pl-1"><button class="btn btn-sm btn-danger p-0 pl-1 pr-1 xoa-mot-ta-vu d-none" data-action="<?php echo e($row['id']); ?>">-</button> <span><?php echo e($row['name']); ?></span></span>

    </label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/Admin/PhanQuyen/tacVu.blade.php ENDPATH**/ ?>