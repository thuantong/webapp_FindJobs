<div class="row" id="nguoi-tim-viec-container">
    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="row">
            <div class="col-lg-4 col-xl-4">
                <div class="card-box text-center">
                    <form>

                        <?php echo csrf_field(); ?>
                        <input type="file" id="update_avatar" class="d-none">

                        <img class="rounded-circle avatar-xl img-thumbnail"
                             src="<?php if($data['nguoi_tim_viec']['avatar'] != null): ?><?php echo e(URL::asset($data['nguoi_tim_viec']['avatar'])); ?><?php elseif($data['nguoi_tim_viec']['avatar'] == null): ?><?php echo e(URL::asset('images\default-user-icon-8.jpg')); ?><?php endif; ?>"
                             id="avatar-user">

                        <h4 class="mb-0"><?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?><?php echo e(ucwords($data['nguoi_tim_viec']['get_tai_khoan']['ho_ten'])); ?><?php else: ?><?php echo e(Auth::user()->ho_ten); ?><?php endif; ?></h4>


                        
                        
                        
                        

                        <div class="text-left mt-3">
                            <h4 class="font-13 text-uppercase"><?php echo e(__('Giới thiệu bản thân: ')); ?></h4>
                            <p class="font-13 mb-2" id="user_gioi_thieu">
                                <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                    <?php if($data['nguoi_tim_viec']['gioi_thieu'] == null): ?><?php echo e('Chưa có giới thiệu'); ?><?php else: ?><?php echo e($data['nguoi_tim_viec']['gioi_thieu']); ?><?php endif; ?>
                                <?php else: ?>
                                    <textarea class="form-control"
                                               placeholder="<?php if($data['nguoi_tim_viec']['gioi_thieu'] == null): ?><?php echo e('NULL'); ?><?php endif; ?>"><?php if($data['nguoi_tim_viec']['gioi_thieu'] != null): ?><?php echo e($data['nguoi_tim_viec']['gioi_thieu']); ?><?php endif; ?></textarea>
                                    <?php endif; ?>

                            </p>
                            <p class="mb-2 font-13"><strong><?php echo e(__('Số điện thoại:')); ?></strong><span
                                    class="ml-2">
                                    <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                        <?php if($data['nguoi_tim_viec']['get_tai_khoan']['phone'] == null): ?><?php echo e('Chưa có giới thiệu'); ?><?php else: ?><?php echo e($data['nguoi_tim_viec']['get_tai_khoan']['phone']); ?><?php endif; ?>
                                    <?php else: ?>
                                        <input class="form-control phone not-null" title="Số điện thoại"
                                               value="<?php echo e(Auth::user()->phone); ?>"
                                               autocomplete="off">
                                    <?php endif; ?>
                                        </span>
                                <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>
                            </p>

                            <p class="mb-2 font-13"><strong><?php echo e('Email :'); ?></strong> <span
                                    class="ml-2 ">
                                    <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                        <?php if($data['nguoi_tim_viec']['get_tai_khoan']['email'] == null): ?><?php echo e('Chưa có email'); ?><?php else: ?><?php echo e($data['nguoi_tim_viec']['get_tai_khoan']['email']); ?><?php endif; ?>
                                    <?php else: ?>
                                        <input class="form-control email not-null" data-rule="email"
                                               title="Email" value="<?php echo e(Auth::user()->email); ?>"
                                               autocomplete="off">
                                    <?php endif; ?>

                                </span>
                                <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>
                            </p>


                        </div>


                    </form>

                </div> <!-- end card-box -->

                <div class="card-box position-relative" id="render-skill">
                    <h4 class="header-title"><?php echo e(__('Kỹ năng công việc')); ?>

                        <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                        <?php else: ?>
                            <button class="btn btn-sm btn-pink pt-0 pb-0 pr-1 pl-1 ml-1"
                                    id="add-new-skill"><?php echo e(__('+')); ?></button>
                        <?php endif; ?>
                    </h4>
                    <?php echo $__env->make('User.nguoiTimViec.skillAppend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div> <!-- end card-box-->

            </div> <!-- end col-->

            <div class="col-lg-8 col-xl-8">
                <div class="card-box position-relative">
                    
                    
                    <ul class="nav nav-pills navtab-bg">
                        <li class="nav-item">

                            <a href="#settings" data-toggle="tab" aria-expanded="false" class="nav-link active">
                                <i class="mdi mdi-settings-outline mr-1"></i><?php echo e(__('Thông tin cơ bản')); ?>

                            </a>

                        </li>
                        <li class="nav-item">
                            <a href="#about-me-exp" data-toggle="tab" aria-expanded="true"
                               class="nav-link ml-0">
                                <i class="mdi mdi-face-profile mr-1"></i><?php echo e(__('Kinh nghiệm')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#about-me-exp2" data-toggle="tab" aria-expanded="true"
                               class="nav-link ml-0">
                                <i class="mdi mdi-face-profile mr-1"></i><?php echo e(__('Hồ sơ')); ?>

                            </a>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane" id="about-me-exp2">

                            <div class="row">































                                <?php if($data['nguoi_tim_viec']['file_path'] != null): ?>
                                    <div class="col-sm-12 col-md-12">

                                        
                                        
                                        <iframe src="<?php if($data['nguoi_tim_viec']['file_path'] != null): ?><?php echo e(URL::asset($data['nguoi_tim_viec']['file_path'])); ?><?php endif; ?>" style="width: calc(100%);height: 500px"></iframe>
                                        <a href="<?php if($data['nguoi_tim_viec']['file_path'] != null): ?><?php echo e(URL::asset($data['nguoi_tim_viec']['file_path'])); ?><?php endif; ?>" class="btn btn-primary waves-effect waves-light position-absolute" style="right: 0px"><i class="fa fa-arrows"></i></a>
                                        

                                        

                                        
                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="tab-pane" id="about-me-exp">

                            <h5 class="mb-4 text-uppercase bg-light p-2"><i class="mdi mdi-briefcase mr-1"></i>
                                <?php echo e(__('Kinh nghiệm làm việc')); ?>

                                <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-pink pt-0 pb-0 pr-1 pl-1 ml-1"
                                            id="add-new-exp"><?php echo e(__('+')); ?></button>
                                <?php endif; ?>

                            </h5>

                            <ul class="list-unstyled timeline-sm" id="exp-list">
                                <?php echo $__env->make('User.nguoiTimViec.htmlKinhNghiemLamViec', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </ul>

                            <h5 class="mb-3 mt-4 text-uppercase d-none bg-light p-2"><i
                                    class="mdi mdi-cards-variant mr-1"></i>
                                <?php echo e(__('Dự án')); ?>

                                <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-pink pt-0 pb-0 pr-1 pl-1 ml-1"
                                            id="add-new-project"><?php echo e(__('+')); ?></button>
                                <?php endif; ?>

                            </h5>
                            <div class="table-responsive d-none">
                                <table class="table table-bordered mb-0 table-project" id="table-project">
                                    <thead class="thead-light">
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(__('Tên dự án')); ?></th>
                                        <th><?php echo e(__('Thời gian bắt đầu')); ?></th>
                                        <th><?php echo e(__('Ngày hoàn thành')); ?></th>
                                        <th><?php echo e(__('Trạng thái')); ?></th>
                                        <th><?php echo e(__('Liên kết')); ?></th>
                                        <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                        <?php else: ?>
                                            <th><?php echo e(__('Chức năng')); ?></th>
                                        <?php endif; ?>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php echo $__env->make('User.nguoiTimViec.projectsAppend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <!-- end timeline content-->

                        <div class="tab-pane show active" id="settings">
                            <form>
                                <h5 class="mb-3 text-uppercase bg-light p-2"><i
                                        class="mdi mdi-account-circle mr-1"></i><?php echo e(__('Thông tin cá nhân')); ?></h5>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="ho_ten"><?php echo e(__('Họ và tên: ')); ?></label>
                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['get_tai_khoan']['ho_ten'] != null): ?><?php echo e(ucwords($data['nguoi_tim_viec']['get_tai_khoan']['ho_ten'])); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <input type="text" class="form-control not-null" id="ho_ten"
                                                       title="Họ và tên"
                                                       placeholder="Nhập họ và tên" value="<?php echo e(Auth::user()->ho_ten); ?>">
                                            <?php endif; ?>

                                            <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="gioi_tinh"><?php echo e(__('Giới tính')); ?></label>
                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['gioi_tinh'] != null): ?>
                                                    <?php switch($data['nguoi_tim_viec']['gioi_tinh']):
                                                        case (1): ?>
                                                        <?php echo e('Nam'); ?>

                                                        <?php break; ?>
                                                        <?php case (2): ?>
                                                            <?php echo e('Nữ'); ?>

                                                        <?php break; ?>
                                                        <?php endswitch; ?>
                                                    <?php endif; ?></p>
                                            <?php else: ?>
                                                <select class="form-control not-null" id="gioi_tinh" title="Giới tính">
                                                    <option value="" disabled selected
                                                            class="text-center"><?php echo e(__('Chọn giới tính')); ?></option>
                                                    <option value="1"
                                                            <?php if($data['nguoi_tim_viec']['gioi_tinh'] != null && $data['nguoi_tim_viec']['gioi_tinh'] == 1): ?> selected <?php endif; ?>><?php echo e(__('Nam')); ?></option>
                                                    <option value="2"
                                                            <?php if($data['nguoi_tim_viec']['gioi_tinh'] != null && $data['nguoi_tim_viec']['gioi_tinh'] == 2): ?> selected <?php endif; ?>><?php echo e(__('Nữ')); ?></option>
                                                </select>
                                            <?php endif; ?>


                                            <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>

                                        </div>
                                    </div> <!-- end col -->
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="ngay_sinh"><?php echo e(__('Ngày sinh')); ?></label>
                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['ngay_sinh'] == '' || $data['nguoi_tim_viec']['ngay_sinh'] == null): ?><?php echo e(''); ?><?php else: ?><?php echo e(\Illuminate\Support\Carbon::createFromFormat('Y-m-d',$data['nguoi_tim_viec']['ngay_sinh'])->format('d/m/Y')); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <input class="form-control not-null" title="Ngày sinh"
                                                       placeholder="<?php if($data['nguoi_tim_viec']['ngay_sinh'] == '' || $data['nguoi_tim_viec']['ngay_sinh'] == null): ?><?php echo e('Chọn ngày sinh'); ?><?php endif; ?>"
                                                       id="ngay_sinh"
                                                       value="<?php if($data['nguoi_tim_viec']['ngay_sinh'] == '' || $data['nguoi_tim_viec']['ngay_sinh'] == null): ?><?php echo e(''); ?><?php else: ?><?php echo e(\Illuminate\Support\Carbon::createFromFormat('Y-m-d',$data['nguoi_tim_viec']['ngay_sinh'])->format('d/m/Y')); ?><?php endif; ?>">
                                            <?php endif; ?>

                                            <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>
                                        </div>
                                    </div> <!-- end col -->
                                </div> <!-- end row -->

                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label
                                                for="muc_tieu_nghe_nghiep"><?php echo e(__('Mục tiêu nghề nghiệp:')); ?></label>
                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['muc_tieu_nghe_nghiep'] != null): ?><?php echo e($data['nguoi_tim_viec']['muc_tieu_nghe_nghiep']); ?><?php else: ?><?php echo e(__('Chưa có miêu tả mục tiêu nghề nghiệp')); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <textarea class="form-control" id="muc_tieu_nghe_nghiep"
                                                          placeholder="Hãy viết gì đó..."><?php if($data['nguoi_tim_viec']['muc_tieu_nghe_nghiep'] != null): ?><?php echo e($data['nguoi_tim_viec']['muc_tieu_nghe_nghiep']); ?><?php endif; ?></textarea>
                                            <?php endif; ?>

                                        </div>
                                    </div> <!-- end col -->
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="so_thich"><?php echo e(__('Sở thích:')); ?></label>
                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['so_thich'] != null): ?><?php echo e($data['nguoi_tim_viec']['so_thich']); ?><?php else: ?><?php echo e(__('Chưa có miêu tả sở thích')); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <textarea class="form-control" id="so_thich"
                                                          placeholder="Hãy viết gì đó..."><?php if($data['nguoi_tim_viec']['so_thich'] != null): ?><?php echo e($data['nguoi_tim_viec']['so_thich']); ?><?php endif; ?></textarea>
                                            <?php endif; ?>

                                        </div>
                                    </div> <!-- end col -->
                                </div> <!-- end row -->

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="dia_chi"><?php echo e(__('Địa chỉ')); ?></label>

                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['dia_chi'] != null): ?><?php echo e($data['nguoi_tim_viec']['dia_chi']); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <input type="text" class="form-control" id="dia_chi"
                                                       value="<?php if($data['nguoi_tim_viec']['dia_chi'] != null): ?><?php echo e($data['nguoi_tim_viec']['dia_chi']); ?><?php endif; ?>"
                                                       placeholder="Nhập địa chỉ">
                                            <?php endif; ?>

                                            
                                            
                                        </div>

                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="khu_vuc"><?php echo e(__('Khu vực')); ?></label>
                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['get_dia_diem'] != null): ?><?php echo e($data['nguoi_tim_viec']['get_dia_diem']['name']); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <select class="form-control not-null" id="khu_vuc" title="Chọn khu vực">
                                                    <option disabled selected value=""><?php echo e(__('Chọn khu vực')); ?></option>
                                                    <?php $__currentLoopData = $data['dia_diem']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($row['id']); ?>"
                                                                <?php if($data['nguoi_tim_viec']['dia_diem_id'] != null): ?> <?php if($data['nguoi_tim_viec']['dia_diem_id'] == $row['id']): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($row['name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php endif; ?>

                                            <span class="invalid-feedback" role="alert">
                                        <strong></strong>
                                    </span>
                                        </div>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    </div> <!-- end col -->
                                </div> <!-- end row -->

                                <h5 class="mb-3 text-uppercase bg-light p-2"><i
                                        class="mdi mdi-office-building mr-1"></i><?php echo e(__('Thông tin tìm việc')); ?></h5>
                                <div class="row">
                                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                                <label><?php echo e(__('Mức lương mong muốn: ')); ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 d-flex">
                                                <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                    <p><?php if($data['nguoi_tim_viec']['muc_luong'] != null): ?>
                                                        <div class="bg-light center-element pl-2 pr-2 border">Từ</div>
                                                        <input type="text"
                                                               class="form-control text-center font-weight-bold text-primary"
                                                               id="muc_luong_from"
                                                               value="<?php if($data['nguoi_tim_viec']['muc_luong'] != null): ?><?php echo e(trim(substr($data['nguoi_tim_viec']['muc_luong'],0,strpos($data['nguoi_tim_viec']['muc_luong'],'-'))).' Triệu'); ?><?php else: ?><?php echo e(0); ?><?php endif; ?>"
                                                               placeholder="Nhập mức lương" readonly>

                                                        <div class="bg-light center-element pl-2 pr-2 border">Đến</div>
                                                        <input type="text"
                                                               class="form-control text-center font-weight-bold text-primary"
                                                               id="muc_luong_to"
                                                               value="<?php if($data['nguoi_tim_viec']['muc_luong'] != null): ?><?php echo e(trim(substr($data['nguoi_tim_viec']['muc_luong'],strpos($data['nguoi_tim_viec']['muc_luong'],'-')+1)).' Triệu'); ?><?php else: ?><?php echo e(0); ?><?php endif; ?>"
                                                               placeholder="Nhập mức lương" readonly>

                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <input type="text"
                                                           class="form-control text-center font-weight-bold text-primary"
                                                           id="muc_luong_from"
                                                           value="<?php if($data['nguoi_tim_viec']['muc_luong'] != null): ?><?php echo e(trim(substr($data['nguoi_tim_viec']['muc_luong'],0,strpos($data['nguoi_tim_viec']['muc_luong'],'-')))); ?><?php else: ?><?php echo e(0); ?><?php endif; ?>"
                                                           placeholder="Nhập mức lương">
                                                    <input type="text"
                                                           class="form-control text-center font-weight-bold text-primary"
                                                           id="muc_luong_to"
                                                           value="<?php if($data['nguoi_tim_viec']['muc_luong'] != null): ?><?php echo e(trim(substr($data['nguoi_tim_viec']['muc_luong'],strpos($data['nguoi_tim_viec']['muc_luong'],'-')+1))); ?><?php else: ?><?php echo e(0); ?><?php endif; ?>"
                                                           placeholder="Nhập mức lương">
                                                <?php endif; ?>


                                            </div>

                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12 col-md-5 col-lg-5 col-xl-5">
                                        <div class="form-group">
                                            <label for="hoc_van"><?php echo e(__('Học vấn:')); ?></label>

                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['get_bang_cap'] != null): ?><?php echo e($data['nguoi_tim_viec']['get_bang_cap']['name']); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <select class="form-control not-null hoc_van" id="hoc_van"
                                                        title="Học vấn">
                                                    <option disabled selected value=""><?php echo e(__('Chọn học vấn')); ?></option>
                                                    <?php $__currentLoopData = $data['bang_cap']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($row['id'] != 1): ?>
                                                            <option value="<?php echo e($row['id']); ?>"
                                                                    <?php if($data['nguoi_tim_viec']['bang_cap_id'] != null): ?> <?php if($data['nguoi_tim_viec']['bang_cap_id'] == $row['id']): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($row['name']); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php endif; ?>

                                            <span class="invalid-feedback" role="alert">
                                        <strong></strong>
                                    </span>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-7 col-lg-7 col-xl-7">
                                        <div class="form-group">
                                            <label
                                                for="ten_truong_tot_nghiep"><?php echo e(__('Tên trường tốt nghiệp: ')); ?></label>

                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['ten_truong_tot_nghiep'] != null): ?><?php echo e($data['nguoi_tim_viec']['ten_truong_tot_nghiep']); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <input class="form-control ten_truong_tot_nghiep"
                                                       value="<?php if($data['nguoi_tim_viec']['ten_truong_tot_nghiep'] != null): ?><?php echo e($data['nguoi_tim_viec']['ten_truong_tot_nghiep']); ?><?php endif; ?>"
                                                       id="ten_truong_tot_nghiep"
                                                       placeholder="VD: Trường Đại Học Công Nghiệp Thành Phố HCM.">
                                            <?php endif; ?>

                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12 col-md-5 col-lg-5 col-xl-5">
                                        <div class="form-group">
                                            <label for="loai_cong_viec"><?php echo e(__('Loại công việc')); ?></label>

                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['get_kieu_lam_viec'] != null): ?><?php echo e($data['nguoi_tim_viec']['get_kieu_lam_viec']['name']); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <select class="form-control loai_cong_viec" id="loai_cong_viec">
                                                    <option disabled selected value=""><?php echo e(__('Loại công việc')); ?></option>
                                                    <?php $__currentLoopData = $data['kieu_lam_viec']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($row['id']); ?>"
                                                                <?php if($data['nguoi_tim_viec']['kieu_lam_viec_id'] != null): ?> <?php if($data['nguoi_tim_viec']['kieu_lam_viec_id'] == $row['id']): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($row['name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-7 col-lg-7 col-xl-7">
                                        <div class="form-group">
                                            <label for="vt_ung_tuyen"><?php echo e(__('Vị trí ứng tuyển')); ?></label>

                                            <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                                                <p><?php if($data['nguoi_tim_viec']['vi_tri_tim'] != null): ?><?php echo e($data['nguoi_tim_viec']['vi_tri_tim']); ?><?php endif; ?></p>
                                            <?php else: ?>
                                                <input type="text" class="form-control" id="vt_ung_tuyen"
                                                       value="<?php if($data['nguoi_tim_viec']['vi_tri_tim'] != null): ?><?php echo e($data['nguoi_tim_viec']['vi_tri_tim']); ?><?php endif; ?>"
                                                       placeholder="Nhập vị trí ứng tuyển">
                                                <span class="form-text text-muted"><small>Vị trí ứng tuyển dùng để hiện cho nhà tuyển dụng thấy, hoặc để lọc bài tuyển dụng</small></span>
                                            <?php endif; ?>

                                        </div>

                                    </div>
                                </div>

                                <h5 class="mb-3 text-uppercase bg-light p-2"><i class="mdi mdi-earth mr-1"></i>
                                    <?php echo e(__('Mạng xã hội:')); ?></h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="social-fb">Facebook</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-facebook-official"></i></span>
                                                </div>
                                                <input type="text" class="form-control social-link" id="social-fb"
                                                       value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[0]); ?><?php endif; ?>"
                                                       placeholder="Url" <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?> readonly <?php endif; ?>>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="social-tw">Twitter</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-twitter"></i></span>
                                                </div>
                                                <input type="text" class="form-control social-link" id="social-tw"
                                                       value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[1]); ?><?php endif; ?>"
                                                       placeholder="Username" <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?> readonly <?php endif; ?>>
                                            </div>
                                        </div>
                                    </div> <!-- end col -->
                                </div> <!-- end row -->

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="social-insta">Instagram</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-instagram"></i></span>
                                                </div>
                                                <input type="text" class="form-control social-link"
                                                       id="social-insta"
                                                       value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[2]); ?><?php endif; ?>"
                                                       placeholder="Url" <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?> readonly <?php endif; ?>>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="social-lin">Linkedin</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-linkedin"></i></span>
                                                </div>
                                                <input type="text" class="form-control social-link" id="social-lin"
                                                       value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[3]); ?><?php endif; ?>"
                                                       placeholder="Url" <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?> readonly <?php endif; ?>>
                                            </div>
                                        </div>
                                    </div> <!-- end col -->
                                </div> <!-- end row -->

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="social-sky">Skype</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-skype"></i></span>
                                                </div>
                                                <input type="text" class="form-control social-link" id="social-sky"
                                                       value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[4]); ?><?php endif; ?>"
                                                       placeholder="@username" <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?> readonly <?php endif; ?>>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="social-gh">Github</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-github"></i></span>
                                                </div>
                                                <input type="text" class="form-control social-link" id="social-gh"
                                                       value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[5]); ?><?php endif; ?>"
                                                       placeholder="Username" <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?> readonly <?php endif; ?>>
                                            </div>
                                        </div>
                                    </div> <!-- end col -->
                                </div> <!-- end row -->


                                
                                
                                
                                
                                
                            </form>
                        </div>
                        <!-- end settings content-->

                    </div> <!-- end tab-content -->
                </div> <!-- end card-box-->

            </div> <!-- end col -->
        </div>
    </div>
</div>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/NguoiTimViec/chiTiet.blade.php ENDPATH**/ ?>