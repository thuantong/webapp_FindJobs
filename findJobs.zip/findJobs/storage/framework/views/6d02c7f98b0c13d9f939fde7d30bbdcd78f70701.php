<?php $__env->startSection('content'); ?>
    <head>
        <link href="assets\libs\multiselect\multi-select.css" rel="stylesheet" type="text/css">
        <link href="assets\libs\select2\select2.min.css" rel="stylesheet" type="text/css">
        <!-- ION Slider -->
        <link href="assets\libs\ion-rangeslider\ion.rangeSlider.css" rel="stylesheet" type="text/css">
        
        <link href="assets\libs\bootstrap-touchspin\jquery.bootstrap-touchspin.min.css" rel="stylesheet">

        
        <link href="assets\libs\bootstrap-datepicker\bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
    </head>

    <div id="update_avatar_crop" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('Cập nhật ảnh đại diện')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body p-0">
                    <div class="demo-wrap upload-demo">
                        <div class="container">
                            <div class="row">

                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                    <div class="upload-msg">
                                        Upload a file to start cropping
                                    </div>
                                    <div class="upload-demo-wrap m-0 text-center">
                                        <div id="upload-demo"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary waves-effect"
                            data-dismiss="modal"><?php echo e(__('Thoát')); ?></button>
                    <button type="button" class="btn btn-info waves-effect waves-light" id="get-result-avata">
                        <?php echo e(__('Lưu lại')); ?>

                    </button>
                </div>
            </div>
        </div>
    </div><!-- /.modal -->
    <?php echo $__env->make('User.modal.doiMatKhau', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('User.modal.capNhatProject', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('User.modal.capNhatExp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="page-title-box mb-1">
                <div class="page-title-right">
                    
                    
                    
                    
                    
                    
                    
                    
                    
                </div>
                <h4 class="page-title"><?php echo e(__('Thông tin cá nhân')); ?></h4>
            </div>
        </div>

    </div>

    <div class="row" id="scroll-fixed">

        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card-box p-1 mb-1 text-right">
                <div class="btn-group btn-group-sm" style="float: none;">
                    <a class="btn btn-sm btn-primary text-white mr-4" data-toggle="modal"
                       data-target="#modal-doi-mat-khau"><?php echo e(__('Đổi mật khẩu')); ?></a>
                    
                    <button class="btn btn-success btn-sm save-profile"><?php echo e(__('Lưu lại tất cả')); ?></button>
                    <button class="btn btn-secondary btn-sm cancel-profile"><?php echo e(__('Không lưu')); ?></button>

                </div>

            </div>

        </div>
    </div>
    <div class="row" id="nguoi-tim-viec-container">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="row">
                <div class="col-lg-4 col-xl-4">
                    <div class="card-box text-center">
                        <form>


                            <?php echo csrf_field(); ?>
                            <input type="file" id="update_avatar" class="d-none">

                            <img class="rounded-circle avatar-xl img-thumbnail"
                                 src="<?php if($data['nguoi_tim_viec']['avatar'] != null): ?><?php echo e(URL::asset($data['nguoi_tim_viec']['avatar'])); ?><?php elseif($data['nguoi_tim_viec']['avatar'] == null): ?><?php echo e(URL::asset('images\default-user-icon-8.jpg')); ?><?php endif; ?>"
                                 id="avatar-user">

                            <h4 class="mb-0 mt-1 text-capitalize"><?php echo e(Auth::user()->ho_ten); ?></h4>


                            
                            
                            
                            

                            <div class="text-left mt-3">
                                <h4 class="font-13 text-uppercase"><?php echo e(__('Giới thiệu bản thân: ')); ?></h4>
                                <p class="font-13 mb-2" id="user_gioi_thieu">
                                    <textarea class="form-control"
                                              placeholder="<?php if($data['nguoi_tim_viec']['gioi_thieu'] == null): ?><?php echo e('NULL'); ?><?php endif; ?>"><?php if($data['nguoi_tim_viec']['gioi_thieu'] != null): ?><?php echo e($data['nguoi_tim_viec']['gioi_thieu']); ?><?php endif; ?></textarea>
                                </p>
                                <p class="mb-2 font-13"><strong><?php echo e(__('Số điện thoại:')); ?><abbr style="color: red">*</abbr></strong><span
                                        class="ml-2">
                                        <input class="form-control phone not-null" title="Số điện thoại"
                                               value="<?php echo e(Auth::user()->phone); ?>"
                                               autocomplete="off"></span>
                                    <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>
                                </p>

                                <p class="mb-2 font-13"><strong><?php echo e('Email :'); ?></strong><abbr style="color: red">*</abbr> <span
                                        class="ml-2 "><input class="form-control email not-null" data-rule="email"
                                                             title="Email" value="<?php echo e(Auth::user()->email); ?>"
                                                             autocomplete="off"></span>
                                    <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>
                                </p>


                            </div>


                        </form>

                    </div> <!-- end card-box -->

                    <div class="card-box position-relative" id="render-skill">
                        <h4 class="header-title"><?php echo e(__('Kỹ năng công việc')); ?>

                            <button class="btn btn-sm btn-pink pt-0 pb-0 pr-1 pl-1 ml-1"
                                    id="add-new-skill"><?php echo e(__('+')); ?></button>

                        </h4>

                    </div> <!-- end card-box-->

                </div> <!-- end col-->

                <div class="col-lg-8 col-xl-8">
                    <div class="card-box position-relative">
                        
                        
                        <ul class="nav nav-pills navtab-bg">
                            <li class="nav-item">

                                <a href="#settings" data-toggle="tab" aria-expanded="false" class="nav-link active">
                                    <i class="mdi mdi-settings-outline mr-1"></i><?php echo e(__('Thông tin cơ bản')); ?>

                                </a>

                            </li>
                            <li class="nav-item">
                                <a href="#about-me-exp" data-toggle="tab" aria-expanded="true"
                                   class="nav-link ml-0">
                                    <i class="mdi mdi-face-profile mr-1"></i><?php echo e(__('Kinh nghiệm')); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#about-me-exp2" data-toggle="tab" aria-expanded="true"
                                   class="nav-link ml-0">
                                    <i class="mdi mdi-face-profile mr-1"></i><?php echo e(__('Hồ sơ')); ?>

                                </a>
                            </li>






                        </ul>

                        <div class="tab-content">
                            <div class="tab-pane" id="about-me-exp2">

                                <div class="row">
                                    <div class="col-sm-12 col-md-12">
                                        Tải ảnh CV mới lên:
                                    </div>
                                    <div class="col-sm-12 col-md-12">
                                        <form class="row" action="<?php echo e(route('nguoitimviec.uploadFile')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>


                                            <div class="col-sm-12 col-md-12">
                                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($message); ?>


                                                </div>
                                                <h4></h4>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-sm-6 col-md-6">
                                                <input type="file" name="file" id="file_pdf">
                                            </div>
                                            <div class="col-sm-6 col-md-6">
                                                <button type="submit" class="btn btn-primary">Tải lên</button>
                                            </div>
                                            




                                        </form>

                                    </div>
                                    <?php if($data['nguoi_tim_viec']['file_path'] != null): ?>
                                    <div class="col-sm-12 col-md-12">


                                            <iframe src="<?php if($data['nguoi_tim_viec']['file_path'] != null): ?><?php echo e(URL::asset($data['nguoi_tim_viec']['file_path'])); ?><?php endif; ?>" style="width: calc(100%);height: 500px"></iframe>





                                    </div>
                                        <?php endif; ?>
                                </div>

                            </div>
                            <div class="tab-pane" id="about-me-exp">

                                <h5 class="mb-4 text-uppercase bg-light p-2"><i class="mdi mdi-briefcase mr-1"></i>
                                    <?php echo e(__('Kinh nghiệm làm việc')); ?>

                                    <button class="btn btn-sm btn-pink pt-0 pb-0 pr-1 pl-1 ml-1"
                                            id="add-new-exp"><?php echo e(__('+')); ?></button>
                                </h5>

                                <ul class="list-unstyled timeline-sm" id="exp-list">
                                    <?php echo $__env->make('User.nguoiTimViec.htmlKinhNghiemLamViec', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </ul>

                                <h5 class="mb-3 mt-4 text-uppercase d-none bg-light p-2"><i
                                        class="mdi mdi-cards-variant mr-1"></i>
                                    <?php echo e(__('Dự án đã thực hiện')); ?>

                                    <button class="btn btn-sm btn-pink pt-0 pb-0 pr-1 pl-1 ml-1"
                                            id="add-new-project"><?php echo e(__('+')); ?></button>

                                </h5>
                                <div class="table-responsive d-none">
                                    <table class="table table-bordered mb-0 table-project" id="table-project">
                                        <thead class="thead-light">
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(__('Tên dự án')); ?></th>
                                            <th><?php echo e(__('Thời gian bắt đầu')); ?></th>
                                            <th><?php echo e(__('Ngày hoàn thành')); ?></th>
                                            <th class="d-none"><?php echo e(__('Trạng thái')); ?></th>
                                            <th><?php echo e(__('Chức vụ')); ?></th>
                                            <th><?php echo e(__('Chức năng')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php echo $__env->make('User.nguoiTimViec.projectsAppend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                            <!-- end timeline content-->

                            <div class="tab-pane show active" id="settings">
                                <form>
                                    <h5 class="mb-3 text-uppercase bg-light p-2"><i
                                            class="mdi mdi-account-circle mr-1"></i><?php echo e(__('Thông tin cá nhân')); ?></h5>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="ho_ten"><?php echo e(__('Họ và tên: ')); ?><abbr style="color: red">*</abbr></label>
                                                <input type="text" class="form-control not-null" id="ho_ten"
                                                       title="Họ và tên"
                                                       placeholder="Nhập họ và tên" value="<?php echo e(Auth::user()->ho_ten); ?>">
                                                <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="gioi_tinh"><?php echo e(__('Giới tính')); ?><abbr style="color: red">*</abbr></label>

                                                <select class="form-control not-null" id="gioi_tinh" title="Giới tính">
                                                    <option value="" disabled selected
                                                            class="text-center"><?php echo e(__('Chọn giới tính')); ?></option>
                                                    <option value="1"
                                                            <?php if($data['nguoi_tim_viec']['gioi_tinh'] != null && $data['nguoi_tim_viec']['gioi_tinh'] == 1): ?> selected <?php endif; ?>><?php echo e(__('Nam')); ?></option>
                                                    <option value="2"
                                                            <?php if($data['nguoi_tim_viec']['gioi_tinh'] != null && $data['nguoi_tim_viec']['gioi_tinh'] == 2): ?> selected <?php endif; ?>><?php echo e(__('Nữ')); ?></option>
                                                </select>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>

                                            </div>
                                        </div> <!-- end col -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="ngay_sinh"><?php echo e(__('Ngày sinh')); ?><abbr style="color: red">*</abbr></label>
                                                <input class="form-control not-null" title="Ngày sinh"
                                                       placeholder="<?php if($data['nguoi_tim_viec']['ngay_sinh'] == '' || $data['nguoi_tim_viec']['ngay_sinh'] == null): ?><?php echo e('Chọn ngày sinh'); ?><?php endif; ?>"
                                                       id="ngay_sinh"
                                                       value="<?php if($data['nguoi_tim_viec']['ngay_sinh'] == '' || $data['nguoi_tim_viec']['ngay_sinh'] == null): ?><?php echo e(''); ?><?php else: ?><?php echo e(\Illuminate\Support\Carbon::createFromFormat('Y-m-d',$data['nguoi_tim_viec']['ngay_sinh'])->format('d/m/Y')); ?><?php endif; ?>">
                                                <span class="invalid-feedback" role="alert">
                                                    <strong></strong>
                                                </span>
                                            </div>
                                        </div> <!-- end col -->
                                    </div> <!-- end row -->

                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label
                                                    for="muc_tieu_nghe_nghiep"><?php echo e(__('Mục tiêu nghề nghiệp:')); ?></label>
                                                <textarea class="form-control" id="muc_tieu_nghe_nghiep"
                                                          placeholder="Hãy viết gì đó..."><?php if($data['nguoi_tim_viec']['muc_tieu_nghe_nghiep'] != null): ?><?php echo e($data['nguoi_tim_viec']['muc_tieu_nghe_nghiep']); ?><?php endif; ?></textarea>
                                            </div>
                                        </div> <!-- end col -->
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="so_thich"><?php echo e(__('Sở thích:')); ?></label>
                                                <textarea class="form-control" id="so_thich"
                                                          placeholder="Hãy viết gì đó..."><?php if($data['nguoi_tim_viec']['so_thich'] != null): ?><?php echo e($data['nguoi_tim_viec']['so_thich']); ?><?php endif; ?></textarea>
                                            </div>
                                        </div> <!-- end col -->
                                    </div> <!-- end row -->

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="dia_chi"><?php echo e(__('Địa chỉ')); ?></label>
                                                <input type="text" class="form-control" id="dia_chi"
                                                       value="<?php if($data['nguoi_tim_viec']['dia_chi'] != null): ?><?php echo e($data['nguoi_tim_viec']['dia_chi']); ?><?php endif; ?>"
                                                       placeholder="Nhập địa chỉ">
                                                
                                                
                                            </div>

                                        </div>
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label for="khu_vuc"><?php echo e(__('Khu vực')); ?><abbr style="color: red">*</abbr></label>

                                                                                        <select class="form-control not-null" id="khu_vuc" title="Chọn khu vực">
                                                                                            <option disabled selected value=""><?php echo e(__('Chọn khu vực')); ?></option>
                                                                                            <?php $__currentLoopData = $data['dia_diem']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                <option value="<?php echo e($row['id']); ?>"
                                                                                                        <?php if($data['nguoi_tim_viec']['dia_diem_id'] != null): ?> <?php if($data['nguoi_tim_viec']['dia_diem_id'] == $row['id']): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($row['name']); ?></option>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </select>
                                                                                        <span class="invalid-feedback" role="alert">
                                        <strong></strong>
                                    </span>
                                                                                    </div>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                                                                </div> <!-- end col -->
                                    </div> <!-- end row -->

                                    <h5 class="mb-3 text-uppercase bg-light p-2"><i
                                            class="mdi mdi-office-building mr-1"></i><?php echo e(__('Thông tin tìm việc')); ?></h5>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                            <div class="row">
                                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                                    <label><?php echo e(__('Mức lương mong muốn: ')); ?></label>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 d-flex">

                                                    <input type="text"
                                                           class="form-control text-center font-weight-bold text-primary"
                                                           id="muc_luong_from"
                                                           value="<?php if($data['nguoi_tim_viec']['muc_luong'] != null && strlen($data['nguoi_tim_viec']['muc_luong']) != 1): ?><?php echo e(trim(substr($data['nguoi_tim_viec']['muc_luong'],0,strpos($data['nguoi_tim_viec']['muc_luong'],'-')))); ?><?php else: ?><?php echo e(0); ?><?php endif; ?>"
                                                           placeholder="Nhập mức lương">
                                                    <input type="text"
                                                           class="form-control text-center font-weight-bold text-primary"
                                                           id="muc_luong_to"
                                                           value="<?php if($data['nguoi_tim_viec']['muc_luong'] != null && strlen($data['nguoi_tim_viec']['muc_luong']) != 1): ?><?php echo e(trim(substr($data['nguoi_tim_viec']['muc_luong'],strpos($data['nguoi_tim_viec']['muc_luong'],'-')+1))); ?><?php else: ?><?php echo e(0); ?><?php endif; ?>"
                                                           placeholder="Nhập mức lương">
                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-12 col-md-5 col-lg-5 col-xl-5">
                                            <div class="form-group">
                                                <label for="hoc_van"><?php echo e(__('Học vấn:')); ?><abbr style="color: red">*</abbr></label>
                                                <select class="form-control not-null hoc_van" id="hoc_van"
                                                        title="Học vấn">
                                                    <option disabled selected value=""><?php echo e(__('Chọn học vấn')); ?></option>
                                                    <?php $__currentLoopData = $data['bang_cap']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($row['id'] != 1): ?>
                                                            <option value="<?php echo e($row['id']); ?>"
                                                                    <?php if($data['nguoi_tim_viec']['bang_cap_id'] != null): ?> <?php if($data['nguoi_tim_viec']['bang_cap_id'] == $row['id']): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($row['name']); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <span class="invalid-feedback" role="alert">
                                        <strong></strong>
                                    </span>
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-7 col-lg-7 col-xl-7">
                                            <div class="form-group">
                                                <label
                                                    for="ten_truong_tot_nghiep"><?php echo e(__('Tên trường tốt nghiệp: ')); ?></label>
                                                <input class="form-control ten_truong_tot_nghiep"
                                                       value="<?php if($data['nguoi_tim_viec']['ten_truong_tot_nghiep'] != null): ?><?php echo e($data['nguoi_tim_viec']['ten_truong_tot_nghiep']); ?><?php endif; ?>"
                                                       id="ten_truong_tot_nghiep"
                                                       placeholder="VD: Trường Đại Học Công Nghiệp Thành Phố HCM.">
                                            </div>

                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-12 col-md-5 col-lg-5 col-xl-5">
                                            <div class="form-group">
                                                <label for="loai_cong_viec"><?php echo e(__('Loại công việc')); ?></label>
                                                <select class="form-control loai_cong_viec" id="loai_cong_viec">
                                                    <option disabled selected value=""><?php echo e(__('Loại công việc')); ?></option>
                                                    <?php $__currentLoopData = $data['kieu_lam_viec']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($row['id']); ?>"
                                                                <?php if($data['nguoi_tim_viec']['kieu_lam_viec_id'] != null): ?> <?php if($data['nguoi_tim_viec']['kieu_lam_viec_id'] == $row['id']): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($row['name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-7 col-lg-7 col-xl-7">
                                            <div class="form-group">
                                                <label for="vt_ung_tuyen"><?php echo e(__('Vị trí ứng tuyển')); ?></label>
                                                <input type="text" class="form-control" id="vt_ung_tuyen"
                                                       value="<?php if($data['nguoi_tim_viec']['vi_tri_tim'] != null): ?><?php echo e($data['nguoi_tim_viec']['vi_tri_tim']); ?><?php endif; ?>"
                                                       placeholder="Nhập vị trí ứng tuyển">
                                                <span class="form-text text-muted"><small>Vị trí ứng tuyển dùng để hiện cho nhà tuyển dụng thấy, hoặc để lọc bài tuyển dụng</small></span>
                                            </div>
                                            
                                            
                                            
                                            
                                            
                                            
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-4">
                                            <label>Trạng thái tìm việc</label>
                                        </div>

                                        <div class="col-sm-12 col-md-8">
                                            <select class="form-control" id="status-jobs">

                                                <option value="" selected disabled>Chưa chọn trạng thái</option>
                                                <option value="1" <?php if(isset($data['nguoi_tim_viec']) && $data['nguoi_tim_viec']['status_job'] != null && $data['nguoi_tim_viec']['status_job'] == 1): ?><?php echo e('selected'); ?><?php endif; ?>>Tôi đã sẵn sàng tìm việc</option>
                                                <option value="2" <?php if(isset($data['nguoi_tim_viec']) && $data['nguoi_tim_viec']['status_job'] != null && $data['nguoi_tim_viec']['status_job'] == 2): ?><?php echo e('selected'); ?><?php endif; ?>>Tôi chưa sẵn sàng tìm việc mới</option>
                                            </select>
                                        </div>
                                    </div>
                                    <h5 class="mb-3 text-uppercase bg-light p-2"><i class="mdi mdi-earth mr-1"></i>
                                        <?php echo e(__('Mạng xã hội:')); ?></h5>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="social-fb">Facebook</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-facebook-official"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control social-link" id="social-fb"
                                                           value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[0]); ?><?php endif; ?>"
                                                           placeholder="Url">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="social-tw">Twitter</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-twitter"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control social-link" id="social-tw"
                                                           value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[1]); ?><?php endif; ?>"
                                                           placeholder="Username">
                                                </div>
                                            </div>
                                        </div> <!-- end col -->
                                    </div> <!-- end row -->

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="social-insta">Instagram</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-instagram"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control social-link"
                                                           id="social-insta"
                                                           value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[2]); ?><?php endif; ?>"
                                                           placeholder="Url">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="social-lin">Linkedin</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-linkedin"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control social-link" id="social-lin"
                                                           value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[3]); ?><?php endif; ?>"
                                                           placeholder="Url">
                                                </div>
                                            </div>
                                        </div> <!-- end col -->
                                    </div> <!-- end row -->

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="social-sky">Skype</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-skype"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control social-link" id="social-sky"
                                                           value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[4]); ?><?php endif; ?>"
                                                           placeholder="@username">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="social-gh">Github</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-github"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control social-link" id="social-gh"
                                                           value="<?php if($data['nguoi_tim_viec']['social'] != null): ?><?php echo e(unserialize($data['nguoi_tim_viec']['social'])[5]); ?><?php endif; ?>"
                                                           placeholder="Username">
                                                </div>
                                            </div>
                                        </div> <!-- end col -->
                                    </div> <!-- end row -->


                                    
                                    
                                    
                                    
                                    
                                </form>
                            </div>
                            <!-- end settings content-->

                        </div> <!-- end tab-content -->
                    </div> <!-- end card-box-->

                </div> <!-- end col -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    

    <!-- Ion Range Slider-->
    <script src="<?php echo e(URL::asset('assets\libs\ion-rangeslider\ion.rangeSlider.min.js')); ?>"></script>

    <!-- Range slider init js-->
    <script src="<?php echo e(URL::asset('assets\js\pages\range-sliders.init.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\multiselect\jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\jquery-quicksearch\jquery.quicksearch.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\select2\select2.min.js')); ?>"></script>

    
    <script src="<?php echo e(URL::asset('assets\libs\bootstrap-datepicker\bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\bootstrap-touchspin\jquery.bootstrap-touchspin.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\nguoiTimViec.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\cap-nhat-kinh-nghiem.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\cap-nhat-project.js')); ?>"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.2.4/pdfobject.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.2.4/pdfobject.js"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\date-picker-vi.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\doi_mat_khau.js')); ?>"></script>
    <script type="text/javascript">
        
        
        
        // $('#load-file-pdf').attr('src',filePDF)

        var $uploadCrop;

        function readFile(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('.upload-demo').addClass('ready');
                    $uploadCrop.croppie('bind', {
                        url: e.target.result,
                    }).then(function () {
                        console.log('jQuery bind complete');
                    });
                };
                //
                reader.readAsDataURL(input.files[0]);
            } else {
                swal('Sorry - you\'re browser doesn\'t support the FileReader API');
            }
        }

        //
        $uploadCrop = $('#upload-demo').croppie({
            viewport: {
                width: 200,
                height: 200,
                // type: 'circle'
            },
            enableExif: true,
        });

        $(function () {
            $('body').addClass('enlarged');

            $('#avatar-user').on('click', function () {
                // alert();
                $('#update_avatar').trigger('click');
            });
            $('#update_avatar').on('change', function () {
                $('#update_avatar_crop').modal('show');
                readFile(this);
            });
            $('#get-result-avata').on('click', function (ev) {
                // $('.jq-toast-wrap .jq-toast-single').find('#message').text('Sửa ảnh đại diện');
                let namePicture = $('#update_avatar')[0].files[0].name;
                // console.log();
                $uploadCrop.croppie('result', {
                    type: 'canvas',
                    size: 'viewport',
                }).then(function (resp) {
                    // console.log(resp);
                    $.ajax({
                        method: 'post',
                        url: '/user-set-avatar',
                        data: {
                            fileName: resp,
                            name: namePicture,
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                        },

                        success: res => {
                            $('#avatar-user').attr('src', res);
                            // $('#toastr-three').click();
                            // $.toast({
                            //     heading: 'Sửa thành công!',
                            //     hideAfter: 2000,
                            //     icon: 'success',
                            //     loaderBg: '#5ba035',
                            //     position: 'top-right',
                            //     stack: 1,
                            //     text: 'Thay đổi ảnh đại diện thành công',
                            // });
                            $('#update_avatar_crop').modal('hide');
                            // console.log(res)
                        },
                    });
                });
            });
        });
        // document.getElementById('save-doi-mat-khau').addEventListener('click', function () {
        //     let arraySend = {
        //             password_old: $('.password-old').val(),
        //             password_new: $('.password-new').val(),
        //             re_password_new: $('.re-password-new').val(),
        //         }
        //     ;
        //     let arrayCustom =
        //         {
        //             beforeSendElement: $(this).attr('id'),
        //             resHeading: 'Đổi mật khẩu',
        //             password_old: $('.password-old'),
        //             password_new: $('.password-new'),
        //             re_password_new: $('.re-password-new'),
        //         };
        //     getResponseAjax('post', '/doi-mat-khau', arraySend, arrayCustom);
        // });

        // var fixedScroll = $('#scroll-fixed').offset();
        // const headerTop = fixedScroll.top;
        // $(window).on('scroll', function () {
        //
        //     // console.log(fixedScroll.top, window.pageYOffset + 70);
        //     if (window.pageYOffset + 70 >= headerTop) {
        //         $('#scroll-fixed').addClass('scroll-fixed-top');
        //     } else {
        //         $('#scroll-fixed').removeClass('scroll-fixed-top');
        //     }
        // });
        // $(document).on('click', '.call-save-profile', function () {
        //     $('.save-profile,.cancel-profile').removeClass('d-none').fadeIn();
        //     $('.call-save-profile').addClass('d-none');
        // });
        // $(document).on('click', '.save-profile', function () {
        //     $('.save-profile,.cancel-profile').addClass('d-none');
        //     $('.call-save-profile').removeClass('d-none').fadeIn();
        //
        // });
        // $(document).on('click', '.cancel-profile', function () {
        //     $('.save-profile,.cancel-profile').addClass('d-none');
        //     $('.call-save-profile').removeClass('d-none').fadeIn();
        //
        // });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/User/nguoiTimViec.blade.php ENDPATH**/ ?>