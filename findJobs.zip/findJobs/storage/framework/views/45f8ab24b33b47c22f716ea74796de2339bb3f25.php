<?php if($typeSend == 0): ?>

    <div class="pt-1 skill">
        <h6 class="text-uppercase mt-0 mb-1 row">
            <label class="col-6 mb-0 d-flex"><input class="skill-name check-null" data-value="" data-prefix="" title=""
                                                    value="" placeholder="<?php echo e(__('VD: Java')); ?>"><abbr
                    class="text-danger font-15 pl-1"><?php echo e(__('*')); ?></abbr></label>

            <span class="float-right col-6 text-right"><span
                    class="skill_value"></span> Điểm<button
                    class="btn btn-sm btn-danger pt-0 pb-0 pr-1 pl-1 ml-1 remove-skill"><?php echo e(__('-')); ?></button></span>

        </h6>
        <input type="text" class="skill_append" data-value="<?php echo e(__('NULL')); ?>">
    </div>
<?php elseif($typeSend == 1): ?>
    <?php if($data['nguoi_tim_viec']['ky_nang'] != null): ?>

        <?php $__currentLoopData = $data['nguoi_tim_viec']['ky_nang']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="pt-1 skill">
                <h6 class="text-uppercase mt-0 mb-1 row">
                    <label class="col-6 mb-0 d-flex">
                        <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                            <input class="skill-name check-null" data-value="" data-prefix="" style="border: none"
                                   title="" value="<?php echo e(ucfirst($row['name'])); ?>" placeholder="<?php echo e(__('VD: Java')); ?>" readonly>
                        <?php else: ?>
                            <input class="skill-name check-null" data-value="" data-prefix=""
                                   title="" value="<?php echo e($row['name']); ?>" placeholder="<?php echo e(__('VD: Java')); ?>">
                            <abbr
                                class="text-danger font-15 pl-1"><?php echo e(__('*')); ?></abbr>
                        <?php endif; ?>

                    </label>
                    <?php if(\Illuminate\Support\Arr::exists($data,'chi_tiet_nguoi_tim_viec') == true && $data['chi_tiet_nguoi_tim_viec'] == 1): ?>
                    <?php else: ?>
                        <span class="float-right col-6 text-right"><span
                                class="skill_value"><?php echo e($row['diem']); ?></span> Điểm<button
                                class="btn btn-sm btn-danger pt-0 pb-0 pr-1 pl-1 ml-1 remove-skill"><?php echo e(__('-')); ?></button></span>
                    <?php endif; ?>


                </h6>
                <input type="text" class="skill_append" value="<?php echo e($row['diem']); ?>" data-value="<?php echo e($row['diem']); ?>">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/User/nguoiTimViec/skillAppend.blade.php ENDPATH**/ ?>