<?php $__env->startSection('content'); ?>
    <head>



        <link href="<?php echo e(URL::asset('assets\libs\multiselect\multi-select.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\select2\select2.min.css')); ?>" rel="stylesheet" type="text/css">





    </head>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item active">Tìm kiếm ứng viên</li>
                    </ol>
                </div>
                <h4 class="page-title">Tìm kiếm ứng viên</h4>
            </div>
        </div>
    </div>

    <div class="card-box">

        <form class="row" action="" method="get">
            <div class="col-sm-4 col-md-4">
                <div class="row">
                    <input class="form-control" name="nguoi_tim_viec" placeholder="Tên chức vụ hoặc tên ứng viên" value="<?php if(Request::exists('nguoi_tim_viec')): ?><?php echo e(Request::get('nguoi_tim_viec')); ?><?php endif; ?>">
                </div>

            </div>
            <div class="col-sm-3 col-md-3">
                <div class="row">
                    <select class="col-sm-12 col-md-12 form-control" name="nganh_nghe" id="nganh_nghe">
                        <option selected value="">Tất cả ngành nghề</option>
                        <?php $__currentLoopData = $nganh_nghe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row['id']); ?>" <?php if(Request::exists('nganh_nghe') && Request::get('nganh_nghe') != "" && Request::get('nganh_nghe') == $row['id']): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($row['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

            </div>
            <div class="col-sm-3 col-md-3">
                <div class="row">
                    <select class="col-sm-12 col-md-12 form-control" name="dia_diem" id="dia_diem">
                        <option selected value="">Tất cả địa điểm</option>
                        <?php $__currentLoopData = $dia_diem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row['id']); ?>" <?php if(Request::exists('dia_diem') && Request::get('dia_diem') != "" && Request::get('dia_diem') == $row['id']): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($row['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-2 col-md-2">
                <button type="submit" class="btn btn-primary">Tìm</button>
            </div>
        </form>

    </div>
    <div class="card-box">
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="table-responsive">
                    <table class="col-sm-12 col-md-12 table table-bordered">
                        <thead class="bg-primary">
                        <tr>
                            <th style="width: 50px"></th>
                            <th>Tên</th>

                            <th>Lương</th>
                            <th>Nơi làm việc</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(count($data) > 0): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="width: 100px; padding: 0" class="center-element"><img class="rounded-circle" src="<?php if($row['get_tai_khoan']['avatar'] != null): ?><?php echo e(URL::asset($row['get_tai_khoan']['avatar'])); ?><?php else: ?><?php echo e(URL::asset('images/default-company-logo.jpg')); ?><?php endif; ?>" style="width: calc(100%)"></td>
                                <td>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12 text-capitalize"><?php if($row['viec_can_tim'] != null): ?><?php echo e($row['viec_can_tim']); ?><?php endif; ?></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12 text-capitalize"><?php if($row['get_tai_khoan']['ho_ten'] != null): ?><?php echo e($row['get_tai_khoan']['ho_ten']); ?><?php endif; ?></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">Học vấn: <?php if($row['get_bang_cap']['name'] != null): ?><?php echo e($row['get_bang_cap']['name']); ?><?php endif; ?></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">Cấp bậc: <?php if($row['get_kieu_lam_viec']['name'] != null): ?><?php echo e($row['get_kieu_lam_viec']['name']); ?><?php endif; ?></div>
                                    </div>
                                </td>

                                <td><?php echo e($row['muc_luong']); ?> Triệu</td>
                                <td><?php if($row['get_dia_diem'] != null): ?><?php echo e($row['get_dia_diem']['name']); ?><?php endif; ?></td>
                                <td><a href="<?php echo e(route('nhatuyendung.chiTiet',['nguoi_tim_viec'=>$row['id']])); ?>">Xem</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center"><span><?php echo e('Không tìm thấy ứng viên..'); ?></span></td>
                            </tr>

                            <?php endif; ?>

                        </tbody>
                    </table>
                    <?php if(count($data) > 0): ?>
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <?php echo e($data->links()); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(URL::asset('assets\libs\multiselect\jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\jquery-quicksearch\jquery.quicksearch.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\select2\select2.min.js')); ?>"></script>
    <script>
        $(function () {
            select2Default($('#nganh_nghe'));
            select2Default($('#dia_diem'));
        })
    </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/TimKiemUngVien/index.blade.php ENDPATH**/ ?>