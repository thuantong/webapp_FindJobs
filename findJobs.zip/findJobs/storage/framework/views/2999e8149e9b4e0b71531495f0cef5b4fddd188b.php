<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo e(__('Tìm việc vô song')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
    <meta content="Coderthemes" name="author">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- App favicon -->

    <!-- App css -->
    <link href="<?php echo e(asset('assets\css\bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets\css\app.min.css')); ?>" rel="stylesheet" type="text/css">

</head>

<body>

<!-- Begin page -->
<div id="wrapper">

            <!-- Start Content-->
            <div class="container-fluid">

                <div class="row justify-content-center my-5">
                    <div class="col-lg-12 col-xl-12 col-sm-12 mb-4">
                        <div class="error-text-box">
                            <svg viewbox="0 0 600 200">
                                <!-- Symbol-->
                                <symbol id="s-text">
                                    <text text-anchor="middle" x="50%" y="50%" dy=".35em"><?php echo e($data['code']); ?>!</text>
                                </symbol>
                                <!-- Duplicate symbols-->
                                <use class="text" xlink:href="#s-text"></use>
                                <use class="text" xlink:href="#s-text"></use>
                                <use class="text" xlink:href="#s-text"></use>
                                <use class="text" xlink:href="#s-text"></use>
                                <use class="text" xlink:href="#s-text"></use>
                            </svg>
                        </div>
                        <div class="text-center">
                            <h3 class="mt-0 mb-2"><?php echo e($data['title']); ?></h3>


                            <p class="text-muted mb-3"><?php echo e($data['message']); ?></p>

                            <a href="/" class="btn btn-success waves-effect waves-light"><?php echo e(__('Trở về trang chủ')); ?></a>
                        </div>
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->


            </div> <!-- container -->

</div>

</body>
</html>
<?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/Error/404NotFound.blade.php ENDPATH**/ ?>