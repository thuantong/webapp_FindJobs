<?php $__env->startSection('content'); ?>
    <head>
        
        <link href="<?php echo e(URL::asset('assets\libs\multiselect\multi-select.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\select2\select2.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\bootstrap-datepicker\bootstrap-datepicker.min.css')); ?>" rel="stylesheet"
              type="text/css">

    </head>
    <?php echo $__env->make('User.modal.doiMatKhau', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('CongTy.modal.themMoi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('CongTy.modal.xemAnhDaiDien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('CongTy.modal.anh_dai_dien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="modal fade bs-example-modal-center" id="xem_anh_dai_dien" tabindex="-1" role="dialog"
         aria-labelledby="myCenterModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                
                
                
                
                <div class="modal-body p-0">
                    <button type="button" class="close position-absolute text-danger" style="right: 1rem"
                            data-dismiss="modal"
                            aria-hidden="true">×
                    </button>
                    <img src="" style="width: 100%">
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <div class="modal fade bs-example-modal-center thong-tin" id="doi_anh_dai_dien" tabindex="-1" role="dialog"
         aria-labelledby="myCenterModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('Cập nhật ảnh đại diện')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <div class="demo-wrap upload-demo">
                        
                        <div class="row">

                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                <div class="upload-msg">
                                    Đang tải ảnh
                                </div>
                                <div class="upload-demo-wrap">
                                    <div id="upload-demo"></div>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary waves-effect"
                            data-dismiss="modal" id="close"><?php echo e(__('Thoát')); ?></button>
                    <button type="button" class="btn btn-info waves-effect waves-light" id="save">
                        <?php echo e(__('Chọn ảnh này')); ?>

                    </button>
                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->



    <div class="row">
        <div class="col-12">
            <div class="page-title-box mb-1">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="/">Trang chủ</a></li>
                        <li class="breadcrumb-item"><a>Thông tin</a></li>
                        <li class="breadcrumb-item active">Thông tin nhà tuyển dụng</li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e(__('Phần Nhà Tuyển Dụng')); ?></h4>
            </div>
        </div>
    </div>

    <div class="row" id="scroll-fixed">

        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card-box p-1 mb-1 text-right">
                <div class="btn-group btn-group-sm" style="float: none;">
                    <a class="btn btn-sm btn-primary text-white mr-4" data-toggle="modal"
                       data-target="#modal-doi-mat-khau"><?php echo e(__('Đổi mật khẩu')); ?></a>
                    
                    <button class="btn btn-success btn-sm save-profile"
                            id="save-profile"><?php echo e(__('Lưu lại tất cả')); ?></button>
                    <a class="btn btn-secondary btn-sm cancel-profile" href="/nha-tuyen-dung"><?php echo e(__('Không lưu')); ?></a>
                </div>

            </div>

        </div>
    </div>


    <div class="row center-element nha-tuyen-dung-container">

        <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
            <div class="card-box p-1 mb-1 text-right">
                <div class="row">
                    <label class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
                        <h4 class="bg-light p-2 text-uppercase"><?php echo e(__('Thông Tin Nhà Tuyển Dụng')); ?></h4></label>
                </div>
                <div class="row form-group">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
                        <label for="ho_ten"><abbr class="text-danger  font-15">* </abbr><?php echo e(__('Họ tên: ')); ?></label>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 text-left">
                        <input class="form-control not-null" id="ho_ten" title="Họ tên"
                               placeholder="<?php if(Auth::user()->ho_ten == null): ?><?php echo e("Nhập họ tên"); ?><?php endif; ?>"
                               value="<?php if(Auth::user()->ho_ten != null): ?><?php echo e(Auth::user()->ho_ten); ?><?php endif; ?>">
                        <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
                        <label for="email"><abbr class="text-danger  font-15">* </abbr><?php echo e(__('Email: ')); ?>

                        </label>
                    </div>
                    <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 text-left">
                        <div class="input-group">
                            <input class="form-control email-not-null"
                                   placeholder="<?php if(Auth::user()->email == null): ?><?php echo e("Nhập email"); ?><?php endif; ?>"
                                   id="email" data-rule="email" title="Email người tuyển dụng"
                                   value="<?php if(Auth::user()->email != null): ?><?php echo e(Auth::user()->email); ?><?php endif; ?>">
                            <button
                                class="btn <?php if(Auth::user()->email != Auth::user()->email_confirmed): ?><?php echo e(__('btn-primary')); ?><?php else: ?><?php echo e(__('btn-success')); ?><?php endif; ?>"
                                <?php if(Auth::user()->email != Auth::user()->email_confirmed): ?> id="gui-xac-nhan-email" <?php endif; ?>><?php if(Auth::user()->email != Auth::user()->email_confirmed): ?><?php echo e(__('Gửi xác thực email')); ?><?php else: ?><?php echo e(__('Đã xác nhận')); ?><?php endif; ?></button>
                        </div>
                        <span class="text-success message-response"></span>
                        <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
                    </div>
                </div>

                <div class="row form-group">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
                        <label for="gioi_tinh"><abbr class="text-danger  font-15">* </abbr><?php echo e(__('Địa chỉ')); ?></label>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 text-left">
                        <input class="form-control not-null" id="dia_chi" title="Địa chỉ"
                               value="<?php if($data['nha_tuyen_dung']['dia_chi'] != null): ?><?php echo e($data['nha_tuyen_dung']['dia_chi']); ?><?php endif; ?>">

                        <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
                    </div>

                </div>

                <div class="row form-group">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
                        <label for="gioi_tinh"><abbr class="text-danger  font-15">* </abbr><?php echo e(__('Giới tính')); ?></label>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 text-left">
                        <select class="form-control not-null" id="gioi_tinh_tuyen_dung" title="Giới tính">
                            <option value="" disabled selected
                                    class="text-center"><?php echo e(__('Chọn giới tính')); ?></option>
                            <option value="1"
                                    <?php if($data['nha_tuyen_dung']['gioi_tinh'] != null && $data['nha_tuyen_dung']['gioi_tinh'] == 1): ?> selected <?php endif; ?>><?php echo e(__('Nam')); ?></option>
                            <option value="2"
                                    <?php if($data['nha_tuyen_dung']['gioi_tinh'] != null && $data['nha_tuyen_dung']['gioi_tinh'] == 2): ?> selected <?php endif; ?>><?php echo e(__('Nữ')); ?></option>
                        </select>

                        <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
                    </div>

                </div>

                <div class="row form-group">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
                        <label for="ngay_sinh_tuyen_dung"><abbr
                                class="text-danger  font-15">* </abbr><?php echo e(__('Ngày sinh')); ?></label>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 text-left">
                        <input class="form-control not-null" id="ngay_sinh_tuyen_dung" title="Ngày sinh"
                               value="<?php if($data['nha_tuyen_dung']['nam_sinh'] != null): ?><?php echo e(\Illuminate\Support\Carbon::createFromFormat('Y-m-d',$data['nha_tuyen_dung']['nam_sinh'])->format('d/m/Y')); ?><?php else: ?><?php echo e(date('d/m/Y')); ?><?php endif; ?>">

                        <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
                    </div>

                </div>

                <div class="row form-group">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
                        <label for="phone_tuyen_dung"><abbr
                                class="text-danger  font-15">* </abbr><?php echo e(__('Số điện thoại: ')); ?></label>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 text-left">
                        <input class="form-control not-null"
                               placeholder="<?php if(Auth::user()->phone == null): ?><?php echo e("Nhập số điện thoại"); ?><?php endif; ?>"
                               id="phone_tuyen_dung" title="Số điện thoại"
                               value="<?php if(Auth::user()->phone != null): ?><?php echo e(Auth::user()->phone); ?><?php endif; ?>">
                        <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
                        <label><abbr class="text-danger  font-15">* </abbr><?php echo e(__('Công ty tuyển dụng:')); ?></label>
                    </div>
                    <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
                        <div class="row">
                            <div class="col-sm-9 col-md-10 col-lg-10 col-xl-10 pr-0">
                                <div class="row">
                                    
                                    
                                    <input id="cong_ty_tuyen_dung" class="not-null" title="Công ty tuyển dụng"
                                           type="hidden" title="Công ty"
                                           value="<?php if(isset($data['cong_ty']) && $data['cong_ty']['id'] != null): ?><?php echo e($data['cong_ty']['id']); ?><?php endif; ?>">

                                    
                                    <div class="col-sm-12 col-md-12 text-center"
                                         id="cong_ty_tuyen_dung_name"><?php if(isset($data['cong_ty']) && $data['cong_ty']['name'] != null): ?>
                                            <h5><?php echo e(ucwords($data['cong_ty']['name'])); ?></h5><?php else: ?> <h5><?php echo e('Chưa thêm công ty tuyển dụng'); ?></h5> <?php endif; ?>
                                    </div>
                                    <span class="invalid-feedback" role="alert">
                            <strong></strong>
                        </span>
                                </div>
                                
                                
                                

                                
                                
                                
                                
                                
                                

                                

                            </div>
                            <div class="col-sm-3 col-md-2 col-lg-2 col-xl-2 pl-0">
                                <button class="btn waves-effect btn-primary call-them-moi-cong-ty"
                                        id="call-them-moi-cong-ty">Chỉnh sửa
                                </button>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="row form-group d-none">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center text-md-right">
                        <label for="avatar_tuyen_dung"><?php echo e(__('Ảnh đại diện: ')); ?></label>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 center-element position-relative">
                        <div style="width: 8rem;height: 8rem;" id="avatar_tuyen_dung">
                            
                            <img
                                src="<?php if(Auth::user()->avatar != null): ?><?php echo e(URL::asset(Auth::user()->avatar)); ?><?php else: ?><?php echo e(URL::asset('images\default-user-icon-8.jpg')); ?><?php endif; ?>"
                                class="avatar-xl img-thumbnail" data-data="<?php echo e(Auth::user()->avatar); ?>"
                                alt="profile-image" tabindex="-1" style="width: 100%;height: 100%">
                            <div class="position-absolute center-element"
                                 style="display:none;width: 8rem;height: 8rem;background-color: rgba(50, 58, 70, .55);top:0">
                                <div>
                                    <div class="row mt-1 mb-1">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
                                            <button class="btn btn-success btn-sm">Đổi ảnh</button>
                                            <input type="file" class="d-none">
                                        </div>
                                    </div>
                                    <div class="row mt-1 mb-1">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
                                            <button class="btn btn-light btn-sm">Xem ảnh</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                        <label>Giới thiệu bản thân:</label>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6">
                        <textarea class="form-control"
                                  id="gioi_thieu"><?php if($data['nha_tuyen_dung']['gioi_thieu']): ?><?php echo e($data['nha_tuyen_dung']['gioi_thieu']); ?><?php endif; ?></textarea>
                    </div>
                </div>
                <h5 class="mb-3 text-uppercase bg-light p-2 text-center text-md-left"><i class="mdi mdi-earth mr-1"></i>
                    <?php echo e(__('Mạng xã hội:')); ?></h5>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group text-center text-md-left">
                            <label for="social-fb">Facebook</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-facebook-official"></i></span>
                                </div>
                                
                                <input type="text" class="form-control social-link" id="social-fb"
                                       value="<?php if($data['nha_tuyen_dung']['mang_xa_hoi'] != null): ?><?php echo e(unserialize($data['nha_tuyen_dung']['mang_xa_hoi'])[0]); ?><?php endif; ?>"
                                       placeholder="Url">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group text-center text-md-left">
                            <label for="social-tw">Twitter</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-twitter"></i></span>
                                </div>
                                <input type="text" class="form-control social-link" id="social-tw"
                                       value="<?php if($data['nha_tuyen_dung']['mang_xa_hoi'] != null): ?><?php echo e(unserialize($data['nha_tuyen_dung']['mang_xa_hoi'])[1]); ?><?php endif; ?>"
                                       placeholder="Username">
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group text-center text-md-left">
                            <label for="social-insta">Instagram</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-instagram"></i></span>
                                </div>
                                <input type="text" class="form-control social-link" id="social-insta"
                                       value="<?php if($data['nha_tuyen_dung']['mang_xa_hoi'] != null): ?><?php echo e(unserialize($data['nha_tuyen_dung']['mang_xa_hoi'])[2]); ?><?php endif; ?>"
                                       placeholder="Url">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group text-center text-md-left">
                            <label for="social-lin">Linkedin</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-linkedin"></i></span>
                                </div>
                                <input type="text" class="form-control social-link" id="social-lin"
                                       value="<?php if($data['nha_tuyen_dung']['mang_xa_hoi'] != null): ?><?php echo e(unserialize($data['nha_tuyen_dung']['mang_xa_hoi'])[3]); ?><?php endif; ?>"
                                       placeholder="Url">
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group text-center text-md-left">
                            <label for="social-sky">Skype</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-skype"></i></span>
                                </div>
                                <input type="text" class="form-control social-link" id="social-sky"
                                       value="<?php if($data['nha_tuyen_dung']['mang_xa_hoi'] != null): ?><?php echo e(unserialize($data['nha_tuyen_dung']['mang_xa_hoi'])[4]); ?><?php endif; ?>"
                                       placeholder="@username">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group text-center text-md-left">
                            <label for="social-gh">Github</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                                        <span class="input-group-text"><i
                                                                class="fa fa-github"></i></span>
                                </div>
                                <input type="text" class="form-control social-link" id="social-gh"
                                       value="<?php if($data['nha_tuyen_dung']['mang_xa_hoi'] != null): ?><?php echo e(unserialize($data['nha_tuyen_dung']['mang_xa_hoi'])[5]); ?><?php endif; ?>"
                                       placeholder="Username">
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(URL::asset('assets\libs\multiselect\jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\jquery-quicksearch\jquery.quicksearch.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\select2\select2.min.js')); ?>"></script>

    <script src="<?php echo e(URL::asset('assets\libs\bootstrap-datepicker\bootstrap-datepicker.min.js')); ?>"></script>

    <script type="text/javascript"
            src="<?php echo e(URL::asset('assets\libs\date-time-picker\moment-with-locales.min.js')); ?>"></script>

    <link rel="stylesheet" type="text/css"
          href="<?php echo e(URL::asset('assets\libs\date-time-picker\bootstrap-datetimepicker.css')); ?>">
    <script type="text/javascript"
            src="<?php echo e(URL::asset('assets\libs\date-time-picker\bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\bootstrap-touchspin\jquery.bootstrap-touchspin.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\nhaTuyenDung.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\doi_mat_khau.js')); ?>"></script>
    
    <script type="text/javascript">
        let data_action_confifm = '<?php echo e(Auth::user()->id); ?>';
    </script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\chuc-nang-gui-confirm-email.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\date-picker-vi.js')); ?>"></script>
    <script>
        $(function () {
            var fixedScroll = $('#scroll-fixed').offset();
            const headerTop = fixedScroll.top;
            $(window).on('scroll', function () {

                // console.log(fixedScroll.top, window.pageYOffset + 70);
                if (window.pageYOffset + 70 >= headerTop) {
                    $('#scroll-fixed').addClass('scroll-fixed-top');
                } else {
                    $('#scroll-fixed').removeClass('scroll-fixed-top');
                }
            });
        });
        let HTMLcongTy = null;
        let getBaseURL = '<?php echo e(URL::asset('/')); ?>';
        const initEventCapNhatCongTy = () => {
            $('#doi_anh_dai_dien.congty').data('type', 'them-moi-cong-ty')
            select2Default($('select#from_day'));
            select2Default($('select#to_day'));
            select2Default($('select#quy_mo_nhan_su'));
            select2MultipleDefault($('select#linh_vuc_hoat_dong'), 'Chọn Ngành nghề')
            // $('select#from_day,select#to_day,select#quy_mo_nhan_su').select2({
            //     dropdownParent: $('div#cap-nhat-cong-ty ')
            // });
            // $('select#linh_vuc_hoat_dong').select2({
            //     placeholder: ' Chọn Ngành nghề',
            //     allowClear: false
            // });

            $("#so_luong_chi_nhanh").TouchSpin({
                min: 0,
                buttondown_class: "btn btn-primary waves-effect",
                buttonup_class: "btn btn-primary waves-effect"
            });
            lichNam($('#nam_thanh_lap'));

            $('#from_time,#to_time').datetimepicker({
                format: 'HH:mm',
                widgetPositioning: {
                    vertical: 'bottom',
                    horizontal: 'right'
                },
                icons: {
                    time: "icofont icofont-clock-time",
                    date: "icofont icofont-ui-calendar",
                    up: "icofont icofont-rounded-up",
                    down: "icofont icofont-rounded-down",
                    next: "icofont icofont-rounded-right",
                    previous: "icofont icofont-rounded-left"
                },
            });
            hoverEventLogo();
        }
        const hoverEventLogo = () => {
            $("div#logo_cong_ty").hover(function () {
                if ($(window).width() >= 576) {
                    $(this).find('div.hover-me').fadeIn('fast');
                }
            }, function () {
                if ($(window).width() >= 576) {
                    $(this).find('div.hover-me').fadeOut('fast');
                }
            });
        }
    </script>

    <script type="text/javascript" src="<?php echo e(URL::asset('assets\js\app\themMoiCongTy.js')); ?>"></script>
    <script>
        $(document).on('click', 'button#call-them-moi-cong-ty', function () {
            $('div.modal#them-moi-cong-ty').modal('show');
            let ajax = {
                url: '/danh-sach-cong-ty/get-content',
                method: 'get',
                data: {}
            };
            sendAjaxNoFunc(ajax.method, ajax.url, ajax.data, '').done(e => {
                $('div.modal#them-moi-cong-ty').find('.modal-body').html(e);
                $('div.modal#them-moi-cong-ty').find('.modal-body').find('#save-cong-ty').addClass('d-none');
                initEventCapNhatCongTy()
                // hoverEventLogo();
            })
            // $('div.modal#them-moi-cong-ty').data('type', 'cong_ty_tuyen_dung');
            // alert()
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/User/nhaTuyenDung.blade.php ENDPATH**/ ?>