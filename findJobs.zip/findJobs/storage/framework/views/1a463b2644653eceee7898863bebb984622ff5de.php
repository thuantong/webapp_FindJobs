<?php $__env->startSection('content'); ?>
    <head>



        <link href="<?php echo e(URL::asset('assets\libs\multiselect\multi-select.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(URL::asset('assets\libs\select2\select2.min.css')); ?>" rel="stylesheet" type="text/css">





    </head>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item active">Chi tiết ứng cử viên</li>
                    </ol>
                </div>
                <h4 class="page-title">Chi tiết ứng cử viên</h4>
            </div>
        </div>
    </div>

    <div class="card-box">
        <?php echo $__env->make('NguoiTimViec.chiTiet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>

    <?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(URL::asset('assets\libs\multiselect\jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\jquery-quicksearch\jquery.quicksearch.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\libs\select2\select2.min.js')); ?>"></script>
    <script>

        $(function () {
            $('.skill_append').ionRangeSlider({
                skin: 'round',
                from: $(this).data('value'),
                from_fixed: true,
            });
        //     select2Default($('#nganh_nghe'));
        //     select2Default($('#dia_diem'));
        })
    </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/TimKiemUngVien/chi_tiet.blade.php ENDPATH**/ ?>