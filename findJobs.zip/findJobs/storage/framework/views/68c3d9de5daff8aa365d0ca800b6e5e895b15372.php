<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(URL::asset('/')); ?>">Việc làm</a></li>
                        <li class="breadcrumb-item active">Xem việc làm theo
                            <?php switch(intval($type)):
                                case (1): ?>
                                địa điểm
                                <?php break; ?>
                                <?php case (2): ?>
                                ngành nghề
                                <?php break; ?>
                                <?php case (3): ?>
                                kiểu làm việc
                                <?php break; ?>
                                <?php case (4): ?>
                                chức vụ
                                <?php break; ?>
                            <?php endswitch; ?>
                        </li>
                    </ol>
                </div>
                <h4 class="page-title">Xem việc làm theo <?php switch(intval($type)):
                        case (1): ?>
                        địa điểm
                        <?php break; ?>
                        <?php case (2): ?>
                        ngành nghề
                        <?php break; ?>
                        <?php case (3): ?>
                        kiểu làm việc
                        <?php break; ?>
                        <?php case (4): ?>
                        chức vụ
                        <?php break; ?>
                    <?php endswitch; ?></h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="card-box p-1 mb-1 text-center">
                <div class="row center-element">
                    <div class="col-sm-12 col-md-12">
                        <div class="row">
                            <?php switch(intval($type)):
                                case (1): ?>
                                <?php $__currentLoopData = $dia_diem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="col-sm-4 col-md-4 text-left"
                                       href="<?php echo e(URL::asset('/?dia_diem='.$row['id'])); ?>"><small
                                            class="fa fa-circle font-10 pr-1"></small><span
                                            class="font-20"><?php echo e($row['name']); ?></span></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php break; ?>
                                <?php case (2): ?>
                                <?php $__currentLoopData = $nganh_nghe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="col-sm-4 col-md-4 text-left"
                                       href="<?php echo e(URL::asset('/?nganh_nghe='.$row['id'])); ?>"><small
                                            class="fa fa-circle font-10 pr-1"></small><span
                                            class="font-20"><?php echo e($row['name']); ?></span></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php break; ?>
                                <?php case (3): ?>
                                <?php $__currentLoopData = $kieu_lam_viec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="col-sm-4 col-md-4 text-left"
                                       href="<?php echo e(URL::asset('/?kieu_lam_viec='.$row['id'])); ?>"><small
                                            class="fa fa-circle font-10 pr-1"></small><span
                                            class="font-20"><?php echo e($row['name']); ?></span></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php break; ?>
                                <?php case (4): ?>
                                <?php $__currentLoopData = $chuc_vu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="col-sm-4 col-md-4 text-left"
                                       href="<?php echo e(URL::asset('/?chuc_vu='.$row['id'])); ?>"><small
                                            class="fa fa-circle font-10 pr-1"></small><span
                                            class="font-20"><?php echo e($row['name']); ?></span></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php break; ?>
                            <?php endswitch; ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MTpc\Desktop\khoaluanTN\timvieclam\webapp_FindJobs\findJobs\resources\views/TrangChu/danh_sach_viec_lam.blade.php ENDPATH**/ ?>